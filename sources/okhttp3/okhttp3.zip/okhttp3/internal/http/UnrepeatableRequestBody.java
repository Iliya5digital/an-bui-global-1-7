package okhttp3.internal.http;
/* loaded from: classes69.dex */
public interface UnrepeatableRequestBody {
}
