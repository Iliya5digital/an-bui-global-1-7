package okhttp3.internal;
/* loaded from: classes69.dex */
public final class Version {
    public static String userAgent() {
        return "okhttp/3.9.1";
    }

    private Version() {
    }
}
