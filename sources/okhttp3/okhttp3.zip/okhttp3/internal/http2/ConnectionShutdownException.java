package okhttp3.internal.http2;

import java.io.IOException;
/* loaded from: classes69.dex */
public final class ConnectionShutdownException extends IOException {
}
