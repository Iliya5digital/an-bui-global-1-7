package androidx.transition;

import android.graphics.drawable.Drawable;
import androidx.annotation.NonNull;
/* loaded from: classes51.dex */
interface ViewOverlayImpl {
    void add(@NonNull Drawable drawable);

    void remove(@NonNull Drawable drawable);
}
