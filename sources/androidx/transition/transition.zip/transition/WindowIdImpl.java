package androidx.transition;
/* loaded from: classes51.dex */
interface WindowIdImpl {
}
