package androidx.core.app;

import android.app.Notification;
/* loaded from: classes6.dex */
public interface NotificationBuilderWithBuilderAccessor {
    Notification.Builder getBuilder();
}
