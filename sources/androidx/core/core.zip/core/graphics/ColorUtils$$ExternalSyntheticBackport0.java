package androidx.core.graphics;
/* loaded from: classes6.dex */
public final /* synthetic */ class ColorUtils$$ExternalSyntheticBackport0 {
    public static /* synthetic */ boolean m(Object obj, Object obj2) {
        return obj == obj2 || (obj != null && obj.equals(obj2));
    }
}
