package androidx.core.view;
/* loaded from: classes6.dex */
public final /* synthetic */ class ViewCompat$$ExternalSyntheticLambda0 implements OnReceiveContentViewBehavior {
    public static final /* synthetic */ ViewCompat$$ExternalSyntheticLambda0 INSTANCE = new ViewCompat$$ExternalSyntheticLambda0();

    private /* synthetic */ ViewCompat$$ExternalSyntheticLambda0() {
    }

    @Override // androidx.core.view.OnReceiveContentViewBehavior
    public final ContentInfoCompat onReceiveContent(ContentInfoCompat contentInfoCompat) {
        return ViewCompat.lambda$static$0(contentInfoCompat);
    }
}
