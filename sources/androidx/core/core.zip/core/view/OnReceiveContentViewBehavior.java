package androidx.core.view;
/* loaded from: classes6.dex */
public interface OnReceiveContentViewBehavior {
    ContentInfoCompat onReceiveContent(ContentInfoCompat contentInfoCompat);
}
