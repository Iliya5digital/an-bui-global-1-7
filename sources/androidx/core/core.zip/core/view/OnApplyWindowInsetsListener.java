package androidx.core.view;

import android.view.View;
/* loaded from: classes6.dex */
public interface OnApplyWindowInsetsListener {
    WindowInsetsCompat onApplyWindowInsets(View view, WindowInsetsCompat windowInsetsCompat);
}
