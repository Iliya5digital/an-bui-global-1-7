package androidx.core.view;

import android.view.View;
/* loaded from: classes6.dex */
public interface ViewPropertyAnimatorUpdateListener {
    void onAnimationUpdate(View view);
}
