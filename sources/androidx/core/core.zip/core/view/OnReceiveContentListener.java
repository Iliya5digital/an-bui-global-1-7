package androidx.core.view;

import android.view.View;
/* loaded from: classes6.dex */
public interface OnReceiveContentListener {
    ContentInfoCompat onReceiveContent(View view, ContentInfoCompat contentInfoCompat);
}
