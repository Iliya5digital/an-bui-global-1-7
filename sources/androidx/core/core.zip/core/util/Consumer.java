package androidx.core.util;
/* loaded from: classes6.dex */
public interface Consumer<T> {
    void accept(T t);
}
