package androidx.core.util;
/* loaded from: classes6.dex */
public interface Supplier<T> {
    T get();
}
