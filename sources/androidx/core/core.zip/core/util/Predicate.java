package androidx.core.util;
/* loaded from: classes6.dex */
public interface Predicate<T> {
    boolean test(T t);
}
