package androidx.startup;

import android.content.Context;
import java.util.List;
/* loaded from: classes29.dex */
public interface Initializer<T> {
    /* renamed from: create */
    T mo134create(Context context);

    List<Class<? extends Initializer<?>>> dependencies();
}
