package androidx.savedstate;

import androidx.lifecycle.LifecycleOwner;
/* loaded from: classes17.dex */
public interface SavedStateRegistryOwner extends LifecycleOwner {
    SavedStateRegistry getSavedStateRegistry();
}
