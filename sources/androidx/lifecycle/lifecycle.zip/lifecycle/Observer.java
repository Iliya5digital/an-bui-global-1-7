package androidx.lifecycle;
/* loaded from: classes18.dex */
public interface Observer<T> {
    void onChanged(T t);
}
