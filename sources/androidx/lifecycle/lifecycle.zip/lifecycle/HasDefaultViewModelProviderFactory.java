package androidx.lifecycle;

import androidx.lifecycle.ViewModelProvider;
/* loaded from: classes15.dex */
public interface HasDefaultViewModelProviderFactory {
    ViewModelProvider.Factory getDefaultViewModelProviderFactory();
}
