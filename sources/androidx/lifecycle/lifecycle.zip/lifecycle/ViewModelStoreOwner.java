package androidx.lifecycle;
/* loaded from: classes15.dex */
public interface ViewModelStoreOwner {
    ViewModelStore getViewModelStore();
}
