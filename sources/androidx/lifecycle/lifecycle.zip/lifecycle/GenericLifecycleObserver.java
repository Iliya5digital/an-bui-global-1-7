package androidx.lifecycle;
@Deprecated
/* loaded from: classes13.dex */
public interface GenericLifecycleObserver extends LifecycleEventObserver {
}
