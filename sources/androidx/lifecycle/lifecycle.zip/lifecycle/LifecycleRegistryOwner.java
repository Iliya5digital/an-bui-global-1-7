package androidx.lifecycle;
@Deprecated
/* loaded from: classes10.dex */
public interface LifecycleRegistryOwner extends LifecycleOwner {
    @Override // androidx.lifecycle.LifecycleOwner
    LifecycleRegistry getLifecycle();

    /* renamed from: androidx.lifecycle.LifecycleRegistryOwner$-CC  reason: invalid class name */
    /* loaded from: classes10.dex */
    public final /* synthetic */ class CC {
    }
}
