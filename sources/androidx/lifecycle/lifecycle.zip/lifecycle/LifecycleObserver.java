package androidx.lifecycle;
/* loaded from: classes13.dex */
public interface LifecycleObserver {
}
