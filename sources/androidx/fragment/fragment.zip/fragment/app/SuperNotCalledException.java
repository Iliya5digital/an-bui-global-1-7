package androidx.fragment.app;

import android.util.AndroidRuntimeException;
/* loaded from: classes31.dex */
final class SuperNotCalledException extends AndroidRuntimeException {
    public SuperNotCalledException(String msg) {
        super(msg);
    }
}
