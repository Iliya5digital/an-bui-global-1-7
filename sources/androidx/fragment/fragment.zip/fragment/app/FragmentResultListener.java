package androidx.fragment.app;

import android.os.Bundle;
/* loaded from: classes31.dex */
public interface FragmentResultListener {
    void onFragmentResult(String str, Bundle bundle);
}
