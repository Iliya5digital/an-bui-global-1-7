package androidx.fragment.app;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes31.dex */
public class FragmentManagerImpl extends FragmentManager {
}
