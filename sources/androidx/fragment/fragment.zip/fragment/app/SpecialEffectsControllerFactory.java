package androidx.fragment.app;

import android.view.ViewGroup;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes31.dex */
public interface SpecialEffectsControllerFactory {
    SpecialEffectsController createController(ViewGroup viewGroup);
}
