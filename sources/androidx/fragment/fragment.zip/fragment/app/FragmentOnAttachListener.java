package androidx.fragment.app;
/* loaded from: classes31.dex */
public interface FragmentOnAttachListener {
    void onAttachFragment(FragmentManager fragmentManager, Fragment fragment);
}
