package androidx.versionedparcelable;
/* loaded from: classes14.dex */
public abstract class CustomVersionedParcelable implements VersionedParcelable {
    public void onPreParceling(boolean isStream) {
    }

    public void onPostParceling() {
    }
}
