package androidx.versionedparcelable;
/* loaded from: classes14.dex */
public interface VersionedParcelable {
}
