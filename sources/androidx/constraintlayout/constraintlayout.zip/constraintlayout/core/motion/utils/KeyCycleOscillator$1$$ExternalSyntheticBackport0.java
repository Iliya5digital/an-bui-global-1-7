package androidx.constraintlayout.core.motion.utils;
/* loaded from: classes40.dex */
public final /* synthetic */ class KeyCycleOscillator$1$$ExternalSyntheticBackport0 {
    public static /* synthetic */ int m(int i, int i2) {
        if (i == i2) {
            return 0;
        }
        return i < i2 ? -1 : 1;
    }
}
