package androidx.constraintlayout.core.motion.utils;
/* loaded from: classes40.dex */
public interface DifferentialInterpolator {
    float getInterpolation(float f);

    float getVelocity();
}
