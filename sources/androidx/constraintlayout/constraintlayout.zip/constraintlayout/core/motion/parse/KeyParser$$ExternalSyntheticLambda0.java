package androidx.constraintlayout.core.motion.parse;

import androidx.constraintlayout.core.motion.parse.KeyParser;
import androidx.constraintlayout.core.motion.utils.TypedValues;
/* loaded from: classes40.dex */
public final /* synthetic */ class KeyParser$$ExternalSyntheticLambda0 implements KeyParser.DataType {
    public static final /* synthetic */ KeyParser$$ExternalSyntheticLambda0 INSTANCE = new KeyParser$$ExternalSyntheticLambda0();

    private /* synthetic */ KeyParser$$ExternalSyntheticLambda0() {
    }

    @Override // androidx.constraintlayout.core.motion.parse.KeyParser.DataType
    public final int get(int i) {
        return TypedValues.Attributes.CC.getType(i);
    }
}
