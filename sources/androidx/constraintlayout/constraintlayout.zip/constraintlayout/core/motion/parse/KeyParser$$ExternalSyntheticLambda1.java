package androidx.constraintlayout.core.motion.parse;

import androidx.constraintlayout.core.motion.parse.KeyParser;
import androidx.constraintlayout.core.motion.utils.TypedValues;
/* loaded from: classes40.dex */
public final /* synthetic */ class KeyParser$$ExternalSyntheticLambda1 implements KeyParser.Ids {
    public static final /* synthetic */ KeyParser$$ExternalSyntheticLambda1 INSTANCE = new KeyParser$$ExternalSyntheticLambda1();

    private /* synthetic */ KeyParser$$ExternalSyntheticLambda1() {
    }

    @Override // androidx.constraintlayout.core.motion.parse.KeyParser.Ids
    public final int get(String str) {
        return TypedValues.Attributes.CC.getId(str);
    }
}
