package androidx.constraintlayout.core.widgets.analyzer;
/* loaded from: classes40.dex */
public interface Dependency {
    void update(Dependency dependency);
}
