package androidx.constraintlayout.core.state;
/* loaded from: classes40.dex */
public final /* synthetic */ class Transition$$ExternalSyntheticLambda4 implements Interpolator {
    public static final /* synthetic */ Transition$$ExternalSyntheticLambda4 INSTANCE = new Transition$$ExternalSyntheticLambda4();

    private /* synthetic */ Transition$$ExternalSyntheticLambda4() {
    }

    @Override // androidx.constraintlayout.core.state.Interpolator
    public final float getInterpolation(float f) {
        return Transition.lambda$getInterpolator$4(f);
    }
}
