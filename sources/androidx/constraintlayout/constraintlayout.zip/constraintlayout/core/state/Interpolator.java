package androidx.constraintlayout.core.state;
/* loaded from: classes40.dex */
public interface Interpolator {
    float getInterpolation(float f);
}
