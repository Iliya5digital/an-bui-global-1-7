package androidx.constraintlayout.core.state;
/* loaded from: classes40.dex */
public final /* synthetic */ class Transition$$ExternalSyntheticLambda2 implements Interpolator {
    public static final /* synthetic */ Transition$$ExternalSyntheticLambda2 INSTANCE = new Transition$$ExternalSyntheticLambda2();

    private /* synthetic */ Transition$$ExternalSyntheticLambda2() {
    }

    @Override // androidx.constraintlayout.core.state.Interpolator
    public final float getInterpolation(float f) {
        return Transition.lambda$getInterpolator$2(f);
    }
}
