package androidx.constraintlayout.core.state;
/* loaded from: classes40.dex */
public final /* synthetic */ class Transition$$ExternalSyntheticLambda3 implements Interpolator {
    public static final /* synthetic */ Transition$$ExternalSyntheticLambda3 INSTANCE = new Transition$$ExternalSyntheticLambda3();

    private /* synthetic */ Transition$$ExternalSyntheticLambda3() {
    }

    @Override // androidx.constraintlayout.core.state.Interpolator
    public final float getInterpolation(float f) {
        return Transition.lambda$getInterpolator$3(f);
    }
}
