package androidx.constraintlayout.core.state;
/* loaded from: classes40.dex */
public final /* synthetic */ class Transition$$ExternalSyntheticLambda1 implements Interpolator {
    public static final /* synthetic */ Transition$$ExternalSyntheticLambda1 INSTANCE = new Transition$$ExternalSyntheticLambda1();

    private /* synthetic */ Transition$$ExternalSyntheticLambda1() {
    }

    @Override // androidx.constraintlayout.core.state.Interpolator
    public final float getInterpolation(float f) {
        return Transition.lambda$getInterpolator$1(f);
    }
}
