package androidx.constraintlayout.core.state;
/* loaded from: classes40.dex */
public final /* synthetic */ class Transition$$ExternalSyntheticLambda6 implements Interpolator {
    public static final /* synthetic */ Transition$$ExternalSyntheticLambda6 INSTANCE = new Transition$$ExternalSyntheticLambda6();

    private /* synthetic */ Transition$$ExternalSyntheticLambda6() {
    }

    @Override // androidx.constraintlayout.core.state.Interpolator
    public final float getInterpolation(float f) {
        return Transition.lambda$getInterpolator$6(f);
    }
}
