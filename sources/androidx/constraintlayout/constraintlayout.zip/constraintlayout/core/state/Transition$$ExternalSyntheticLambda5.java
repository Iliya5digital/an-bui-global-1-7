package androidx.constraintlayout.core.state;
/* loaded from: classes40.dex */
public final /* synthetic */ class Transition$$ExternalSyntheticLambda5 implements Interpolator {
    public static final /* synthetic */ Transition$$ExternalSyntheticLambda5 INSTANCE = new Transition$$ExternalSyntheticLambda5();

    private /* synthetic */ Transition$$ExternalSyntheticLambda5() {
    }

    @Override // androidx.constraintlayout.core.state.Interpolator
    public final float getInterpolation(float f) {
        return Transition.lambda$getInterpolator$5(f);
    }
}
