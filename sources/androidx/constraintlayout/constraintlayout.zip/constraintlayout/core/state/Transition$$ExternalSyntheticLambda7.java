package androidx.constraintlayout.core.state;
/* loaded from: classes40.dex */
public final /* synthetic */ class Transition$$ExternalSyntheticLambda7 implements Interpolator {
    public static final /* synthetic */ Transition$$ExternalSyntheticLambda7 INSTANCE = new Transition$$ExternalSyntheticLambda7();

    private /* synthetic */ Transition$$ExternalSyntheticLambda7() {
    }

    @Override // androidx.constraintlayout.core.state.Interpolator
    public final float getInterpolation(float f) {
        return Transition.lambda$getInterpolator$7(f);
    }
}
