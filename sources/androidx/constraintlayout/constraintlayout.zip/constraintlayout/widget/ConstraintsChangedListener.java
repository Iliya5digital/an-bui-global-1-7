package androidx.constraintlayout.widget;
/* loaded from: classes39.dex */
public abstract class ConstraintsChangedListener {
    public void preLayoutChange(int stateId, int constraintId) {
    }

    public void postLayoutChange(int stateId, int constraintId) {
    }
}
