package androidx.constraintlayout.motion.widget;
/* loaded from: classes39.dex */
public interface CustomFloatAttributes {
    float get(String attribute);

    String[] getListOfAttributes();

    void set(String attribute, float value);
}
