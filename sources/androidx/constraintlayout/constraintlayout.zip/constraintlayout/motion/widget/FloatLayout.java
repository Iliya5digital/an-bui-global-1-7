package androidx.constraintlayout.motion.widget;
/* loaded from: classes39.dex */
public interface FloatLayout {
    void layout(float lf, float tf, float rf, float bf);
}
