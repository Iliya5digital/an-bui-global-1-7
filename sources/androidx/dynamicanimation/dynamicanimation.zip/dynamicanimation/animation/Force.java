package androidx.dynamicanimation.animation;
/* loaded from: classes41.dex */
interface Force {
    float getAcceleration(float f, float f2);

    boolean isAtEquilibrium(float f, float f2);
}
