package androidx.customview.widget;
/* loaded from: classes26.dex */
public interface Openable {
    void close();

    boolean isOpen();

    void open();
}
