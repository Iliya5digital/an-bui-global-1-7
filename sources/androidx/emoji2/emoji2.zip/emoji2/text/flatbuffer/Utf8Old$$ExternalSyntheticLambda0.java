package androidx.emoji2.text.flatbuffer;

import java.util.function.Supplier;
/* loaded from: classes27.dex */
public final /* synthetic */ class Utf8Old$$ExternalSyntheticLambda0 implements Supplier {
    public static final /* synthetic */ Utf8Old$$ExternalSyntheticLambda0 INSTANCE = new Utf8Old$$ExternalSyntheticLambda0();

    private /* synthetic */ Utf8Old$$ExternalSyntheticLambda0() {
    }

    @Override // java.util.function.Supplier
    public final Object get() {
        return Utf8Old.lambda$static$0();
    }
}
