package okio;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.channels.WritableByteChannel;
import java.nio.charset.Charset;
/* loaded from: classes70.dex */
public interface BufferedSink extends Sink, WritableByteChannel {
    Buffer buffer();

    BufferedSink emit() throws IOException;

    /* renamed from: emitCompleteSegments */
    BufferedSink mo500emitCompleteSegments() throws IOException;

    @Override // okio.Sink, java.io.Flushable
    void flush() throws IOException;

    OutputStream outputStream();

    /* renamed from: write */
    BufferedSink mo501write(ByteString byteString) throws IOException;

    BufferedSink write(Source source, long j) throws IOException;

    /* renamed from: write */
    BufferedSink mo502write(byte[] bArr) throws IOException;

    /* renamed from: write */
    BufferedSink mo503write(byte[] bArr, int i, int i2) throws IOException;

    long writeAll(Source source) throws IOException;

    /* renamed from: writeByte */
    BufferedSink mo504writeByte(int i) throws IOException;

    /* renamed from: writeDecimalLong */
    BufferedSink mo505writeDecimalLong(long j) throws IOException;

    /* renamed from: writeHexadecimalUnsignedLong */
    BufferedSink mo506writeHexadecimalUnsignedLong(long j) throws IOException;

    /* renamed from: writeInt */
    BufferedSink mo507writeInt(int i) throws IOException;

    /* renamed from: writeIntLe */
    BufferedSink mo508writeIntLe(int i) throws IOException;

    /* renamed from: writeLong */
    BufferedSink mo509writeLong(long j) throws IOException;

    /* renamed from: writeLongLe */
    BufferedSink mo510writeLongLe(long j) throws IOException;

    /* renamed from: writeShort */
    BufferedSink mo511writeShort(int i) throws IOException;

    /* renamed from: writeShortLe */
    BufferedSink mo512writeShortLe(int i) throws IOException;

    /* renamed from: writeString */
    BufferedSink mo513writeString(String str, int i, int i2, Charset charset) throws IOException;

    /* renamed from: writeString */
    BufferedSink mo514writeString(String str, Charset charset) throws IOException;

    /* renamed from: writeUtf8 */
    BufferedSink mo515writeUtf8(String str) throws IOException;

    /* renamed from: writeUtf8 */
    BufferedSink mo516writeUtf8(String str, int i, int i2) throws IOException;

    /* renamed from: writeUtf8CodePoint */
    BufferedSink mo517writeUtf8CodePoint(int i) throws IOException;
}
