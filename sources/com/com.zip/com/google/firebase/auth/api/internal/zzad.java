package com.google.firebase.auth.api.internal;

import androidx.annotation.Nullable;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
final class zzad implements zzff<Void> {
    private final /* synthetic */ zzff zza;
    private final /* synthetic */ zzaa zzb;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzad(zzaa zzaaVar, zzff zzffVar) {
        this.zzb = zzaaVar;
        this.zza = zzffVar;
    }

    @Override // com.google.firebase.auth.api.internal.zzfc
    public final void zza(@Nullable String str) {
        this.zza.zza(str);
    }

    @Override // com.google.firebase.auth.api.internal.zzff
    public final /* synthetic */ void zza(Void r2) {
        this.zzb.zza.zza();
    }
}
