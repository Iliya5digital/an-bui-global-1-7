package com.google.firebase.auth.api.internal;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public final class zzdq {
    private static int zza = -1;
    private static int zzb = -1;

    public static boolean zza() {
        return zza > 0;
    }
}
