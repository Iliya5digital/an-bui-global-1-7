package com.google.firebase.auth.api.internal;

import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.internal.Objects;
import com.google.android.gms.common.internal.Preconditions;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public final class zzek extends zzam implements Api.ApiOptions.HasOptions {
    private final String zzb;

    private zzek(String str) {
        this.zzb = Preconditions.checkNotEmpty(str, "A valid API key must be provided");
    }

    public final String zzb() {
        return this.zzb;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzek)) {
            return false;
        }
        return Objects.equal(this.zzb, ((zzek) obj).zzb);
    }

    public final int hashCode() {
        return Objects.hashCode(this.zzb);
    }

    @Override // com.google.firebase.auth.api.internal.zzam
    public final /* synthetic */ zzam zza() {
        return (zzek) clone();
    }

    @Override // com.google.firebase.auth.api.internal.zzam
    public final /* synthetic */ Object clone() throws CloneNotSupportedException {
        return new zzej(this.zzb).zza();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public /* synthetic */ zzek(String str, zzeh zzehVar) {
        this(str);
    }
}
