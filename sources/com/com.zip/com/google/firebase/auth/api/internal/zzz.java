package com.google.firebase.auth.api.internal;

import androidx.annotation.Nullable;
import com.google.android.gms.common.logging.Logger;
import com.google.android.gms.internal.firebase_auth.zzfs;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
final class zzz implements zzff<zzfs> {
    private final /* synthetic */ zzds zza;
    private final /* synthetic */ zzb zzb;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzz(zzb zzbVar, zzds zzdsVar) {
        this.zzb = zzbVar;
        this.zza = zzdsVar;
    }

    @Override // com.google.firebase.auth.api.internal.zzfc
    public final void zza(@Nullable String str) {
        this.zza.zza(com.google.firebase.auth.internal.zzy.zza(str));
    }

    @Override // com.google.firebase.auth.api.internal.zzff
    public final /* synthetic */ void zza(zzfs zzfsVar) {
        zzat zzatVar;
        Logger logger;
        zzfs zzfsVar2 = zzfsVar;
        if (!zzfsVar2.zzo()) {
            this.zzb.zza(zzfsVar2, this.zza, this);
            return;
        }
        zzatVar = this.zzb.zzc;
        if (zzatVar.zzb()) {
            this.zza.zza(new com.google.android.gms.internal.firebase_auth.zzee(zzfsVar2.zzn(), zzfsVar2.zzm(), zzfsVar2.zzp()));
            return;
        }
        logger = zzb.zza;
        logger.e("Need to do multi-factor auth, but SDK does not support it.", new Object[0]);
        zza("REQUIRES_SECOND_FACTOR_AUTH");
    }
}
