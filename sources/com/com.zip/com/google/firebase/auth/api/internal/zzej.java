package com.google.firebase.auth.api.internal;

import com.google.android.gms.common.internal.Preconditions;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public final class zzej {
    private String zza;

    public zzej(String str) {
        this.zza = Preconditions.checkNotEmpty(str);
    }

    public final zzek zza() {
        return new zzek(this.zza, null);
    }
}
