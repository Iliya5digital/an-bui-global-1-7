package com.google.firebase.auth.api.internal;

import androidx.annotation.Nullable;
import com.google.android.gms.internal.firebase_auth.zzfs;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
final class zzv implements zzff<zzfs> {
    private final /* synthetic */ zzff zza;
    private final /* synthetic */ zzs zzb;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzv(zzs zzsVar, zzff zzffVar) {
        this.zzb = zzsVar;
        this.zza = zzffVar;
    }

    @Override // com.google.firebase.auth.api.internal.zzfc
    public final void zza(@Nullable String str) {
        this.zza.zza(str);
    }

    @Override // com.google.firebase.auth.api.internal.zzff
    public final /* synthetic */ void zza(zzfs zzfsVar) {
        this.zzb.zzb.zza(zzfsVar, this.zzb.zza, this);
    }
}
