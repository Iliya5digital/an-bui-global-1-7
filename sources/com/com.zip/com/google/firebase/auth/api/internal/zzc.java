package com.google.firebase.auth.api.internal;

import androidx.annotation.Nullable;
import com.google.android.gms.common.logging.Logger;
import com.google.android.gms.internal.firebase_auth.zzfz;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
final class zzc implements zzff<zzfz> {
    private final /* synthetic */ zzds zza;
    private final /* synthetic */ zzb zzb;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzc(zzb zzbVar, zzds zzdsVar) {
        this.zzb = zzbVar;
        this.zza = zzdsVar;
    }

    @Override // com.google.firebase.auth.api.internal.zzfc
    public final void zza(@Nullable String str) {
        this.zza.zza(com.google.firebase.auth.internal.zzy.zza(str));
    }

    @Override // com.google.firebase.auth.api.internal.zzff
    public final /* synthetic */ void zza(zzfz zzfzVar) {
        zzat zzatVar;
        Logger logger;
        zzfz zzfzVar2 = zzfzVar;
        if (!zzfzVar2.zzg()) {
            this.zzb.zza(new com.google.android.gms.internal.firebase_auth.zzex(zzfzVar2.zzc(), zzfzVar2.zzb(), Long.valueOf(zzfzVar2.zzd()), "Bearer"), null, null, false, null, this.zza, this);
            return;
        }
        zzatVar = this.zzb.zzc;
        if (zzatVar.zzb()) {
            this.zza.zza(new com.google.android.gms.internal.firebase_auth.zzee(zzfzVar2.zzf(), zzfzVar2.zze(), null));
            return;
        }
        logger = zzb.zza;
        logger.e("Need to do multi-factor auth, but SDK does not support it.", new Object[0]);
        zza("REQUIRES_SECOND_FACTOR_AUTH");
    }
}
