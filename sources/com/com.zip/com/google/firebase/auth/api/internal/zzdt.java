package com.google.firebase.auth.api.internal;

import android.content.Context;
import androidx.annotation.NonNull;
import com.google.android.gms.common.api.GoogleApi;
import com.google.firebase.FirebaseExceptionMapper;
import java.util.concurrent.Callable;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
final class zzdt implements Callable<zzan<zzek>> {
    private final zzek zza;
    private final Context zzb;

    public zzdt(zzek zzekVar, Context context) {
        this.zza = zzekVar;
        this.zzb = context;
    }

    @NonNull
    private final GoogleApi<zzek> zza(boolean z, Context context) {
        zzek zzekVar = (zzek) this.zza.clone();
        zzekVar.zza = z;
        return new zzao(context, zzei.zza, zzekVar, new FirebaseExceptionMapper());
    }

    /* JADX WARN: Code restructure failed: missing block: B:4:0x000e, code lost:
        if (r0 == (-1)) goto L15;
     */
    @Override // java.util.concurrent.Callable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final /* synthetic */ com.google.firebase.auth.api.internal.zzan<com.google.firebase.auth.api.internal.zzek> call() throws java.lang.Exception {
        /*
            r7 = this;
            r3 = 0
            r1 = 1
            r2 = 0
            r4 = -1
            int r0 = com.google.firebase.auth.api.internal.zzdq.zzb()
            if (r0 == r4) goto L10
            int r0 = com.google.firebase.auth.api.internal.zzdq.zzc()
            if (r0 != r4) goto L21
        L10:
            android.content.Context r0 = r7.zzb
            java.lang.String r4 = "com.google.firebase.auth"
            int r4 = com.google.android.gms.dynamite.DynamiteModule.getLocalVersion(r0, r4)
            if (r4 != 0) goto L4a
            r0 = r1
        L1b:
            com.google.firebase.auth.api.internal.zzdq.zza(r0)
            com.google.firebase.auth.api.internal.zzdq.zzb(r4)
        L21:
            int r0 = com.google.firebase.auth.api.internal.zzdq.zzc()
            if (r0 == 0) goto L65
            android.content.Context r0 = r7.zzb
            com.google.android.gms.common.api.GoogleApi r0 = r7.zza(r1, r0)
        L2d:
            int r1 = com.google.firebase.auth.api.internal.zzdq.zzb()
            if (r1 != 0) goto L67
        L33:
            com.google.firebase.auth.api.internal.zzap r1 = new com.google.firebase.auth.api.internal.zzap
            int r2 = com.google.firebase.auth.api.internal.zzdq.zzb()
            int r4 = com.google.firebase.auth.api.internal.zzdq.zzc()
            java.util.Map r5 = java.util.Collections.emptyMap()
            r1.<init>(r2, r4, r5)
            com.google.firebase.auth.api.internal.zzan r2 = new com.google.firebase.auth.api.internal.zzan
            r2.<init>(r3, r0, r1)
            return r2
        L4a:
            com.google.android.gms.common.GoogleApiAvailability r0 = com.google.android.gms.common.GoogleApiAvailability.getInstance()
            android.content.Context r5 = r7.zzb
            r6 = 12451000(0xbdfcb8, float:1.7447567E-38)
            int r0 = r0.isGooglePlayServicesAvailable(r5, r6)
            switch(r0) {
                case 0: goto L5c;
                case 1: goto L5a;
                case 2: goto L5c;
                default: goto L5a;
            }
        L5a:
            r0 = r2
            goto L1b
        L5c:
            android.content.Context r0 = r7.zzb
            java.lang.String r5 = "com.google.android.gms.firebase_auth"
            int r0 = com.google.android.gms.dynamite.DynamiteModule.getRemoteVersion(r0, r5)
            goto L1b
        L65:
            r0 = r3
            goto L2d
        L67:
            android.content.Context r1 = r7.zzb
            com.google.android.gms.common.api.GoogleApi r3 = r7.zza(r2, r1)
            goto L33
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.firebase.auth.api.internal.zzdt.call():java.lang.Object");
    }
}
