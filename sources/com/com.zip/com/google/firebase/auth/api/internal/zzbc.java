package com.google.firebase.auth.api.internal;

import com.google.android.gms.common.Feature;
import com.google.android.gms.common.api.internal.RemoteCall;
import com.google.android.gms.common.api.internal.TaskApiCall;
import com.google.android.gms.common.util.VisibleForTesting;
import com.google.android.gms.tasks.TaskCompletionSource;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
@VisibleForTesting
/* loaded from: classes57.dex */
public final class zzbc extends zzet<Void, com.google.firebase.auth.internal.zzab> {
    public zzbc() {
        super(5);
    }

    @Override // com.google.firebase.auth.api.internal.zzar
    public final String zza() {
        return "delete";
    }

    @Override // com.google.firebase.auth.api.internal.zzar
    public final TaskApiCall<zzdv, Void> zzb() {
        return TaskApiCall.builder().setAutoResolveMissingFeatures(false).setFeatures((this.zzu || this.zzv) ? null : new Feature[]{com.google.android.gms.internal.firebase_auth.zze.zza}).run(new RemoteCall(this) { // from class: com.google.firebase.auth.api.internal.zzbf
            private final zzbc zza;

            /* JADX INFO: Access modifiers changed from: package-private */
            {
                this.zza = this;
            }

            @Override // com.google.android.gms.common.api.internal.RemoteCall
            public final void accept(Object obj, Object obj2) {
                zzbc zzbcVar = this.zza;
                zzdv zzdvVar = (zzdv) obj;
                zzbcVar.zzh = new zzfa(zzbcVar, (TaskCompletionSource) obj2);
                if (zzbcVar.zzu) {
                    zzdvVar.zza().zzg(zzbcVar.zze.zzf(), zzbcVar.zzc);
                } else {
                    zzdvVar.zza().zza(new com.google.android.gms.internal.firebase_auth.zzcc(zzbcVar.zze.zzf()), zzbcVar.zzc);
                }
            }
        }).build();
    }

    @Override // com.google.firebase.auth.api.internal.zzet
    public final void zze() {
        ((com.google.firebase.auth.internal.zzab) this.zzf).zza();
        zzb((zzbc) null);
    }
}
