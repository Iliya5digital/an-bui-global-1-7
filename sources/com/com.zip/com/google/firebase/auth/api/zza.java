package com.google.firebase.auth.api;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public final class zza extends RuntimeException {
    public zza(String str) {
        super(str);
    }

    public zza(Throwable th) {
        super(th);
    }
}
