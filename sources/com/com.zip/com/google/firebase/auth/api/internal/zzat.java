package com.google.firebase.auth.api.internal;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public final class zzat {
    private final zzdz zza;
    private final zzem zzb;

    public zzat(zzdz zzdzVar, zzem zzemVar) {
        this.zza = zzdzVar;
        this.zzb = zzemVar;
    }

    public final boolean zza() {
        return this.zza.zza().booleanValue() && this.zzb.zza();
    }

    public final boolean zzb() {
        return this.zza.zzb().booleanValue() && this.zzb.zza(this.zza.zzc());
    }
}
