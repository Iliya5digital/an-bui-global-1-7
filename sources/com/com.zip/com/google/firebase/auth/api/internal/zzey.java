package com.google.firebase.auth.api.internal;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
final class zzey implements Runnable {
    private final /* synthetic */ zzfb zza;
    private final /* synthetic */ zzev zzb;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzey(zzev zzevVar, zzfb zzfbVar) {
        this.zzb = zzevVar;
        this.zza = zzfbVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        synchronized (this.zzb.zza.zzi) {
            if (!this.zzb.zza.zzi.isEmpty()) {
                this.zza.zza(this.zzb.zza.zzi.get(0), new Object[0]);
            }
        }
    }
}
