package com.google.firebase.auth.api.internal;

import android.text.TextUtils;
import androidx.annotation.Nullable;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.firebase_auth.zzga;
import com.google.firebase.FirebaseError;
import com.google.firebase.auth.PhoneAuthCredential;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
final class zzt implements zzff<zzga> {
    private final /* synthetic */ zzff zza;
    private final /* synthetic */ zzq zzb;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzt(zzq zzqVar, zzff zzffVar) {
        this.zzb = zzqVar;
        this.zza = zzffVar;
    }

    @Override // com.google.firebase.auth.api.internal.zzfc
    public final void zza(@Nullable String str) {
        this.zza.zza(str);
    }

    @Override // com.google.firebase.auth.api.internal.zzff
    public final /* synthetic */ void zza(zzga zzgaVar) {
        zzga zzgaVar2 = zzgaVar;
        if (!TextUtils.isEmpty(zzgaVar2.zzf())) {
            this.zzb.zza.zza(new Status(FirebaseError.ERROR_CREDENTIAL_ALREADY_IN_USE), PhoneAuthCredential.zza(zzgaVar2.zzg(), zzgaVar2.zzf()));
            return;
        }
        this.zzb.zzb.zza(new com.google.android.gms.internal.firebase_auth.zzex(zzgaVar2.zzc(), zzgaVar2.zzb(), Long.valueOf(zzgaVar2.zzd()), "Bearer"), null, "phone", Boolean.valueOf(zzgaVar2.zze()), null, this.zzb.zza, this.zza);
    }
}
