package com.google.firebase.auth.api.internal;

import androidx.annotation.Nullable;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public interface zzfc {
    void zza(@Nullable String str);
}
