package com.google.firebase.auth.api.internal;

import android.content.Context;
import androidx.annotation.Nullable;
import com.google.android.gms.internal.firebase_auth.zzfq;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public final class zzs implements zzff<com.google.android.gms.internal.firebase_auth.zzex> {
    final /* synthetic */ zzds zza;
    final /* synthetic */ zzb zzb;
    private final /* synthetic */ zzfq zzc;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzs(zzb zzbVar, zzfq zzfqVar, zzds zzdsVar) {
        this.zzb = zzbVar;
        this.zzc = zzfqVar;
        this.zza = zzdsVar;
    }

    @Override // com.google.firebase.auth.api.internal.zzfc
    public final void zza(@Nullable String str) {
        this.zza.zza(com.google.firebase.auth.internal.zzy.zza(str));
    }

    @Override // com.google.firebase.auth.api.internal.zzff
    public final /* synthetic */ void zza(com.google.android.gms.internal.firebase_auth.zzex zzexVar) {
        zzat zzatVar;
        zzfd zzfdVar;
        com.google.android.gms.internal.firebase_auth.zzex zzexVar2 = zzexVar;
        zzatVar = this.zzb.zzc;
        if (zzatVar.zza()) {
            this.zzc.zzc(true);
        }
        this.zzc.zza(zzexVar2.zzd());
        zzfdVar = this.zzb.zzb;
        zzfdVar.zza((Context) null, this.zzc, new zzv(this, this));
    }
}
