package com.google.firebase.auth.api.internal;

import androidx.annotation.Nullable;
import com.google.android.gms.internal.firebase_auth.zzep;
import com.google.android.gms.internal.firebase_auth.zzfk;
import java.util.List;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public final class zzh implements zzff<zzep> {
    private final /* synthetic */ zzfc zza;
    private final /* synthetic */ zzds zzb;
    private final /* synthetic */ com.google.android.gms.internal.firebase_auth.zzex zzc;
    private final /* synthetic */ zzfk zzd;
    private final /* synthetic */ zzb zze;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzh(zzb zzbVar, zzfc zzfcVar, zzds zzdsVar, com.google.android.gms.internal.firebase_auth.zzex zzexVar, zzfk zzfkVar) {
        this.zze = zzbVar;
        this.zza = zzfcVar;
        this.zzb = zzdsVar;
        this.zzc = zzexVar;
        this.zzd = zzfkVar;
    }

    @Override // com.google.firebase.auth.api.internal.zzfc
    public final void zza(@Nullable String str) {
        this.zza.zza(str);
    }

    @Override // com.google.firebase.auth.api.internal.zzff
    public final /* synthetic */ void zza(zzep zzepVar) {
        List<com.google.android.gms.internal.firebase_auth.zzer> zzb = zzepVar.zzb();
        if (zzb == null || zzb.isEmpty()) {
            this.zza.zza("No users");
        } else {
            this.zze.zza(this.zzb, this.zzc, zzb.get(0), this.zzd, this.zza);
        }
    }
}
