package com.google.firebase.auth.api.internal;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public interface zzdz {
    Boolean zza();

    Boolean zzb();

    String zzc();
}
