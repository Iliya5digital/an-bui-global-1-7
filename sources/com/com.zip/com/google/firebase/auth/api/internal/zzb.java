package com.google.firebase.auth.api.internal;

import android.content.Context;
import android.text.TextUtils;
import androidx.annotation.Nullable;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.common.logging.Logger;
import com.google.android.gms.internal.firebase_auth.zzen;
import com.google.android.gms.internal.firebase_auth.zzfk;
import com.google.android.gms.internal.firebase_auth.zzfm;
import com.google.android.gms.internal.firebase_auth.zzfn;
import com.google.android.gms.internal.firebase_auth.zzfq;
import com.google.android.gms.internal.firebase_auth.zzfs;
import com.google.android.gms.internal.firebase_auth.zzfv;
import com.google.android.gms.internal.firebase_auth.zzfw;
import com.google.android.gms.internal.firebase_auth.zzfy;
import com.google.android.gms.internal.firebase_auth.zzgc;
import com.google.firebase.FirebaseError;
import com.google.firebase.auth.ActionCodeSettings;
import com.google.firebase.auth.EmailAuthCredential;
import com.google.firebase.auth.UserProfileChangeRequest;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public final class zzb {
    private static final Logger zza = new Logger("FBAuthApiDispatcher", new String[0]);
    private final zzfd zzb;
    private final zzat zzc;

    public zzb(zzfd zzfdVar, zzat zzatVar) {
        this.zzb = (zzfd) Preconditions.checkNotNull(zzfdVar);
        this.zzc = (zzat) Preconditions.checkNotNull(zzatVar);
    }

    public final void zza(String str, zzds zzdsVar) {
        Preconditions.checkNotEmpty(str);
        Preconditions.checkNotNull(zzdsVar);
        this.zzb.zza(new zzen(str), new zza(this, zzdsVar));
    }

    public final void zza(zzfv zzfvVar, zzds zzdsVar) {
        Preconditions.checkNotNull(zzfvVar);
        Preconditions.checkNotNull(zzdsVar);
        this.zzb.zza(zzfvVar, new zzn(this, zzdsVar));
    }

    public final void zza(Context context, zzfq zzfqVar, zzds zzdsVar) {
        Preconditions.checkNotNull(zzfqVar);
        Preconditions.checkNotNull(zzdsVar);
        if (this.zzc.zza()) {
            zzfqVar.zzc(true);
        }
        this.zzb.zza((Context) null, zzfqVar, new zzz(this, zzdsVar));
    }

    public final void zzb(@Nullable String str, zzds zzdsVar) {
        Preconditions.checkNotNull(zzdsVar);
        this.zzb.zza(new zzfm(str), new zzae(this, zzdsVar));
    }

    public final void zza(String str, UserProfileChangeRequest userProfileChangeRequest, zzds zzdsVar) {
        Preconditions.checkNotEmpty(str);
        Preconditions.checkNotNull(userProfileChangeRequest);
        Preconditions.checkNotNull(zzdsVar);
        zza(str, new zzah(this, userProfileChangeRequest, zzdsVar));
    }

    public final void zza(String str, String str2, zzds zzdsVar) {
        Preconditions.checkNotEmpty(str);
        Preconditions.checkNotEmpty(str2);
        Preconditions.checkNotNull(zzdsVar);
        zza(str, new zzag(this, str2, zzdsVar));
    }

    public final void zzb(String str, String str2, zzds zzdsVar) {
        Preconditions.checkNotEmpty(str);
        Preconditions.checkNotEmpty(str2);
        Preconditions.checkNotNull(zzdsVar);
        zza(str, new zzaj(this, str2, zzdsVar));
    }

    public final void zzc(String str, @Nullable String str2, zzds zzdsVar) {
        Preconditions.checkNotEmpty(str);
        Preconditions.checkNotNull(zzdsVar);
        zzfk zzfkVar = new zzfk();
        zzfkVar.zzh(str);
        zzfkVar.zzi(str2);
        this.zzb.zza(zzfkVar, new zzai(this, zzdsVar));
    }

    private final void zza(String str, zzff<com.google.android.gms.internal.firebase_auth.zzex> zzffVar) {
        Preconditions.checkNotNull(zzffVar);
        Preconditions.checkNotEmpty(str);
        com.google.android.gms.internal.firebase_auth.zzex zzb = com.google.android.gms.internal.firebase_auth.zzex.zzb(str);
        if (zzb.zzb()) {
            zzffVar.zza((zzff<com.google.android.gms.internal.firebase_auth.zzex>) zzb);
            return;
        }
        this.zzb.zza(new zzen(zzb.zzc()), new zzal(this, zzffVar));
    }

    public final void zza(String str, String str2, @Nullable String str3, zzds zzdsVar) {
        Preconditions.checkNotEmpty(str);
        Preconditions.checkNotEmpty(str2);
        Preconditions.checkNotNull(zzdsVar);
        this.zzb.zza(new zzfm(str, str2, null, str3), new zzd(this, zzdsVar));
    }

    public final void zza(Context context, String str, String str2, @Nullable String str3, zzds zzdsVar) {
        Preconditions.checkNotEmpty(str);
        Preconditions.checkNotEmpty(str2);
        Preconditions.checkNotNull(zzdsVar);
        this.zzb.zza((Context) null, new zzfw(str, str2, str3), new zzc(this, zzdsVar));
    }

    public final void zza(EmailAuthCredential emailAuthCredential, zzds zzdsVar) {
        Preconditions.checkNotNull(emailAuthCredential);
        Preconditions.checkNotNull(zzdsVar);
        if (emailAuthCredential.zzf()) {
            zza(emailAuthCredential.zze(), new zzf(this, emailAuthCredential, zzdsVar));
        } else {
            zza(new com.google.android.gms.internal.firebase_auth.zzei(emailAuthCredential, null), zzdsVar);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void zza(com.google.android.gms.internal.firebase_auth.zzei zzeiVar, zzds zzdsVar) {
        Preconditions.checkNotNull(zzeiVar);
        Preconditions.checkNotNull(zzdsVar);
        this.zzb.zza(zzeiVar, new zze(this, zzdsVar));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void zza(zzds zzdsVar, com.google.android.gms.internal.firebase_auth.zzex zzexVar, zzfk zzfkVar, zzfc zzfcVar) {
        Preconditions.checkNotNull(zzdsVar);
        Preconditions.checkNotNull(zzexVar);
        Preconditions.checkNotNull(zzfkVar);
        Preconditions.checkNotNull(zzfcVar);
        this.zzb.zza(new com.google.android.gms.internal.firebase_auth.zzem(zzexVar.zzd()), new zzh(this, zzfcVar, zzdsVar, zzexVar, zzfkVar));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void zza(zzds zzdsVar, com.google.android.gms.internal.firebase_auth.zzex zzexVar, com.google.android.gms.internal.firebase_auth.zzer zzerVar, zzfk zzfkVar, zzfc zzfcVar) {
        Preconditions.checkNotNull(zzdsVar);
        Preconditions.checkNotNull(zzexVar);
        Preconditions.checkNotNull(zzerVar);
        Preconditions.checkNotNull(zzfkVar);
        Preconditions.checkNotNull(zzfcVar);
        this.zzb.zza(zzfkVar, new zzg(this, zzfkVar, zzerVar, zzdsVar, zzexVar, zzfcVar));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static com.google.android.gms.internal.firebase_auth.zzex zza(com.google.android.gms.internal.firebase_auth.zzex zzexVar, zzfn zzfnVar) {
        Preconditions.checkNotNull(zzexVar);
        Preconditions.checkNotNull(zzfnVar);
        String zzb = zzfnVar.zzb();
        String zzc = zzfnVar.zzc();
        if (!TextUtils.isEmpty(zzb) && !TextUtils.isEmpty(zzc)) {
            return new com.google.android.gms.internal.firebase_auth.zzex(zzc, zzb, Long.valueOf(zzfnVar.zzd()), zzexVar.zzf());
        }
        return zzexVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void zza(com.google.android.gms.internal.firebase_auth.zzex zzexVar, @Nullable String str, @Nullable String str2, @Nullable Boolean bool, @Nullable com.google.firebase.auth.zzg zzgVar, zzds zzdsVar, zzfc zzfcVar) {
        Preconditions.checkNotNull(zzexVar);
        Preconditions.checkNotNull(zzfcVar);
        Preconditions.checkNotNull(zzdsVar);
        this.zzb.zza(new com.google.android.gms.internal.firebase_auth.zzem(zzexVar.zzd()), new zzj(this, zzfcVar, str2, str, bool, zzgVar, zzdsVar, zzexVar));
    }

    public final void zzd(String str, @Nullable String str2, zzds zzdsVar) {
        Preconditions.checkNotEmpty(str);
        Preconditions.checkNotNull(zzdsVar);
        this.zzb.zza(new com.google.android.gms.internal.firebase_auth.zzef(str, str2), new zzi(this, zzdsVar));
    }

    public final void zza(String str, ActionCodeSettings actionCodeSettings, @Nullable String str2, zzds zzdsVar) {
        com.google.android.gms.internal.firebase_auth.zzev zzevVar;
        Preconditions.checkNotEmpty(str);
        Preconditions.checkNotNull(zzdsVar);
        zzgc zza2 = zzgc.zza(actionCodeSettings.zzd());
        if (zza2 != null) {
            zzevVar = new com.google.android.gms.internal.firebase_auth.zzev(zza2);
        } else {
            zzevVar = new com.google.android.gms.internal.firebase_auth.zzev(zzgc.OOB_REQ_TYPE_UNSPECIFIED);
        }
        zzevVar.zza(str);
        zzevVar.zza(actionCodeSettings);
        zzevVar.zzc(str2);
        this.zzb.zza(zzevVar, new zzl(this, zzdsVar));
    }

    public final void zza(String str, @Nullable ActionCodeSettings actionCodeSettings, zzds zzdsVar) {
        Preconditions.checkNotEmpty(str);
        Preconditions.checkNotNull(zzdsVar);
        com.google.android.gms.internal.firebase_auth.zzev zzevVar = new com.google.android.gms.internal.firebase_auth.zzev(zzgc.VERIFY_EMAIL);
        zzevVar.zzb(str);
        if (actionCodeSettings != null) {
            zzevVar.zza(actionCodeSettings);
        }
        zzb(zzevVar, zzdsVar);
    }

    public final void zze(String str, @Nullable String str2, zzds zzdsVar) {
        Preconditions.checkNotEmpty(str);
        Preconditions.checkNotNull(zzdsVar);
        this.zzb.zza(new com.google.android.gms.internal.firebase_auth.zzff(str, null, str2), new zzk(this, zzdsVar));
    }

    public final void zzb(String str, String str2, @Nullable String str3, zzds zzdsVar) {
        Preconditions.checkNotEmpty(str);
        Preconditions.checkNotEmpty(str2);
        Preconditions.checkNotNull(zzdsVar);
        this.zzb.zza(new com.google.android.gms.internal.firebase_auth.zzff(str, str2, str3), new zzm(this, zzdsVar));
    }

    public final void zza(com.google.android.gms.internal.firebase_auth.zzfj zzfjVar, zzds zzdsVar) {
        Preconditions.checkNotEmpty(zzfjVar.zzb());
        Preconditions.checkNotNull(zzdsVar);
        this.zzb.zza(zzfjVar, new zzp(this, zzdsVar));
    }

    public final void zza(Context context, zzfy zzfyVar, zzds zzdsVar) {
        Preconditions.checkNotNull(zzfyVar);
        Preconditions.checkNotNull(zzdsVar);
        this.zzb.zza((Context) null, zzfyVar, new zzo(this, zzdsVar));
    }

    public final void zzc(String str, String str2, String str3, zzds zzdsVar) {
        Preconditions.checkNotEmpty(str);
        Preconditions.checkNotEmpty(str2);
        Preconditions.checkNotEmpty(str3);
        Preconditions.checkNotNull(zzdsVar);
        zza(str3, new zzr(this, str, str2, zzdsVar));
    }

    public final void zza(Context context, String str, zzfy zzfyVar, zzds zzdsVar) {
        Preconditions.checkNotEmpty(str);
        Preconditions.checkNotNull(zzfyVar);
        Preconditions.checkNotNull(zzdsVar);
        zza(str, new zzq(this, zzfyVar, null, zzdsVar));
    }

    public final void zza(String str, zzfq zzfqVar, zzds zzdsVar) {
        Preconditions.checkNotEmpty(str);
        Preconditions.checkNotNull(zzfqVar);
        Preconditions.checkNotNull(zzdsVar);
        zza(str, new zzs(this, zzfqVar, zzdsVar));
    }

    public final void zzc(String str, zzds zzdsVar) {
        Preconditions.checkNotEmpty(str);
        Preconditions.checkNotNull(zzdsVar);
        zza(str, new zzu(this, zzdsVar));
    }

    public final void zzf(String str, String str2, zzds zzdsVar) {
        Preconditions.checkNotEmpty(str);
        Preconditions.checkNotEmpty(str2);
        Preconditions.checkNotNull(zzdsVar);
        zza(str2, new zzx(this, str, zzdsVar));
    }

    public final void zza(com.google.android.gms.internal.firebase_auth.zzev zzevVar, zzds zzdsVar) {
        zzb(zzevVar, zzdsVar);
    }

    public final void zzd(String str, zzds zzdsVar) {
        Preconditions.checkNotEmpty(str);
        Preconditions.checkNotNull(zzdsVar);
        zza(str, new zzy(this, zzdsVar));
    }

    public final void zze(String str, zzds zzdsVar) {
        Preconditions.checkNotEmpty(str);
        Preconditions.checkNotNull(zzdsVar);
        zza(str, new zzaa(this, zzdsVar));
    }

    public final void zzf(@Nullable String str, zzds zzdsVar) {
        Preconditions.checkNotNull(zzdsVar);
        this.zzb.zza(str, new zzac(this, zzdsVar));
    }

    private final void zzb(com.google.android.gms.internal.firebase_auth.zzev zzevVar, zzds zzdsVar) {
        Preconditions.checkNotNull(zzevVar);
        Preconditions.checkNotNull(zzdsVar);
        this.zzb.zza(zzevVar, new zzaf(this, zzdsVar));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void zza(zzfs zzfsVar, zzds zzdsVar, zzfc zzfcVar) {
        Status zza2;
        if (zzfsVar.zzk()) {
            com.google.firebase.auth.zzg zzp = zzfsVar.zzp();
            String zzd = zzfsVar.zzd();
            String zzl = zzfsVar.zzl();
            if (zzfsVar.zzb()) {
                zza2 = new Status(FirebaseError.ERROR_ACCOUNT_EXISTS_WITH_DIFFERENT_CREDENTIAL);
            } else {
                zza2 = com.google.firebase.auth.internal.zzy.zza(zzfsVar.zzj());
            }
            if (this.zzc.zza()) {
                zzdsVar.zza(new com.google.android.gms.internal.firebase_auth.zzec(zza2, zzp, zzd, zzl));
                return;
            } else {
                zzdsVar.zza(zza2);
                return;
            }
        }
        zza(new com.google.android.gms.internal.firebase_auth.zzex(zzfsVar.zzg(), zzfsVar.zzc(), Long.valueOf(zzfsVar.zzh()), "Bearer"), zzfsVar.zzf(), zzfsVar.zze(), Boolean.valueOf(zzfsVar.zzi()), zzfsVar.zzp(), zzdsVar, zzfcVar);
    }
}
