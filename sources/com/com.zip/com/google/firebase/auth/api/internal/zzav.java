package com.google.firebase.auth.api.internal;

import com.google.android.gms.common.api.UnsupportedApiCallException;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.Task;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public final class zzav implements Continuation<ResultT, Task<ResultT>> {
    private final /* synthetic */ zzar zza;
    private final /* synthetic */ zzas zzb;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzav(zzas zzasVar, zzar zzarVar) {
        this.zzb = zzasVar;
        this.zza = zzarVar;
    }

    @Override // com.google.android.gms.tasks.Continuation
    /* renamed from: then */
    public final /* synthetic */ Object mo428then(Task task) throws Exception {
        if (task.getException() instanceof UnsupportedApiCallException) {
            return this.zzb.zza(this.zza.zzc());
        }
        return task;
    }
}
