package com.google.firebase.auth.api.internal;

import androidx.annotation.Nullable;
import com.google.android.gms.internal.firebase_auth.zzfk;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
final class zzu implements zzff<com.google.android.gms.internal.firebase_auth.zzex> {
    private final /* synthetic */ zzds zza;
    private final /* synthetic */ zzb zzb;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzu(zzb zzbVar, zzds zzdsVar) {
        this.zzb = zzbVar;
        this.zza = zzdsVar;
    }

    @Override // com.google.firebase.auth.api.internal.zzfc
    public final void zza(@Nullable String str) {
        this.zza.zza(com.google.firebase.auth.internal.zzy.zza(str));
    }

    @Override // com.google.firebase.auth.api.internal.zzff
    public final /* synthetic */ void zza(com.google.android.gms.internal.firebase_auth.zzex zzexVar) {
        com.google.android.gms.internal.firebase_auth.zzex zzexVar2 = zzexVar;
        zzfk zzfkVar = new zzfk();
        zzfkVar.zzb(zzexVar2.zzd()).zzc(null).zzd(null);
        this.zzb.zza(this.zza, zzexVar2, zzfkVar, this);
    }
}
