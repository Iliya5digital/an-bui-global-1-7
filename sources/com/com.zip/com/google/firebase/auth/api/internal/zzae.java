package com.google.firebase.auth.api.internal;

import androidx.annotation.Nullable;
import com.google.android.gms.internal.firebase_auth.zzfp;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
final class zzae implements zzff<zzfp> {
    private final /* synthetic */ zzds zza;
    private final /* synthetic */ zzb zzb;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzae(zzb zzbVar, zzds zzdsVar) {
        this.zzb = zzbVar;
        this.zza = zzdsVar;
    }

    @Override // com.google.firebase.auth.api.internal.zzfc
    public final void zza(@Nullable String str) {
        this.zza.zza(com.google.firebase.auth.internal.zzy.zza(str));
    }

    @Override // com.google.firebase.auth.api.internal.zzff
    public final /* synthetic */ void zza(zzfp zzfpVar) {
        zzfp zzfpVar2 = zzfpVar;
        this.zzb.zza(new com.google.android.gms.internal.firebase_auth.zzex(zzfpVar2.zzc(), zzfpVar2.zzb(), Long.valueOf(zzfpVar2.zzd()), "Bearer"), null, null, true, null, this.zza, this);
    }
}
