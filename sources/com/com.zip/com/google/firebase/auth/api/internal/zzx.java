package com.google.firebase.auth.api.internal;

import androidx.annotation.Nullable;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
final class zzx implements zzff<com.google.android.gms.internal.firebase_auth.zzex> {
    final /* synthetic */ String zza;
    final /* synthetic */ zzds zzb;
    final /* synthetic */ zzb zzc;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzx(zzb zzbVar, String str, zzds zzdsVar) {
        this.zzc = zzbVar;
        this.zza = str;
        this.zzb = zzdsVar;
    }

    @Override // com.google.firebase.auth.api.internal.zzfc
    public final void zza(@Nullable String str) {
        this.zzb.zza(com.google.firebase.auth.internal.zzy.zza(str));
    }

    @Override // com.google.firebase.auth.api.internal.zzff
    public final /* synthetic */ void zza(com.google.android.gms.internal.firebase_auth.zzex zzexVar) {
        zzfd zzfdVar;
        com.google.android.gms.internal.firebase_auth.zzex zzexVar2 = zzexVar;
        com.google.android.gms.internal.firebase_auth.zzem zzemVar = new com.google.android.gms.internal.firebase_auth.zzem(zzexVar2.zzd());
        zzfdVar = this.zzc.zzb;
        zzfdVar.zza(zzemVar, new zzw(this, this, zzexVar2));
    }
}
