package com.google.firebase.auth.api.internal;

import android.content.Context;
import androidx.annotation.Nullable;
import com.google.android.gms.internal.firebase_auth.zzfy;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public final class zzq implements zzff<com.google.android.gms.internal.firebase_auth.zzex> {
    final /* synthetic */ zzds zza;
    final /* synthetic */ zzb zzb;
    private final /* synthetic */ zzfy zzc;
    private final /* synthetic */ Context zzd = null;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzq(zzb zzbVar, zzfy zzfyVar, Context context, zzds zzdsVar) {
        this.zzb = zzbVar;
        this.zzc = zzfyVar;
        this.zza = zzdsVar;
    }

    @Override // com.google.firebase.auth.api.internal.zzfc
    public final void zza(@Nullable String str) {
        this.zza.zza(com.google.firebase.auth.internal.zzy.zza(str));
    }

    @Override // com.google.firebase.auth.api.internal.zzff
    public final /* synthetic */ void zza(com.google.android.gms.internal.firebase_auth.zzex zzexVar) {
        zzfd zzfdVar;
        this.zzc.zza(zzexVar.zzd());
        zzfdVar = this.zzb.zzb;
        zzfdVar.zza(this.zzd, this.zzc, new zzt(this, this));
    }
}
