package com.google.firebase.auth.api.internal;

import android.text.TextUtils;
import com.google.android.gms.internal.firebase_auth.zzfy;
import com.google.firebase.auth.PhoneAuthCredential;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public final class zzfh {
    public static zzfy zza(PhoneAuthCredential phoneAuthCredential) {
        if (!TextUtils.isEmpty(phoneAuthCredential.zze())) {
            return zzfy.zzb(phoneAuthCredential.zzc(), phoneAuthCredential.zze(), phoneAuthCredential.zzd());
        }
        return zzfy.zza(phoneAuthCredential.zzb(), phoneAuthCredential.getSmsCode(), phoneAuthCredential.zzd());
    }
}
