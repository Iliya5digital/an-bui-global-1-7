package com.google.firebase.auth.api.internal;

import com.google.android.gms.common.api.Api;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public abstract class zzam implements Api.ApiOptions, Cloneable {
    boolean zza;

    @Override // 
    /* renamed from: zza */
    public abstract zzam clone();
}
