package com.google.firebase.auth.api.internal;

import android.text.TextUtils;
import androidx.annotation.Nullable;
import com.google.android.gms.common.util.Base64Utils;
import com.google.android.gms.internal.firebase_auth.zzfk;
import com.google.android.gms.internal.firebase_auth.zzfn;
import java.util.ArrayList;
import java.util.List;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public final class zzg implements zzff<zzfn> {
    private final /* synthetic */ zzfk zza;
    private final /* synthetic */ com.google.android.gms.internal.firebase_auth.zzer zzb;
    private final /* synthetic */ zzds zzc;
    private final /* synthetic */ com.google.android.gms.internal.firebase_auth.zzex zzd;
    private final /* synthetic */ zzfc zze;
    private final /* synthetic */ zzb zzf;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzg(zzb zzbVar, zzfk zzfkVar, com.google.android.gms.internal.firebase_auth.zzer zzerVar, zzds zzdsVar, com.google.android.gms.internal.firebase_auth.zzex zzexVar, zzfc zzfcVar) {
        this.zzf = zzbVar;
        this.zza = zzfkVar;
        this.zzb = zzerVar;
        this.zzc = zzdsVar;
        this.zzd = zzexVar;
        this.zze = zzfcVar;
    }

    @Override // com.google.firebase.auth.api.internal.zzfc
    public final void zza(@Nullable String str) {
        this.zze.zza(str);
    }

    @Override // com.google.firebase.auth.api.internal.zzff
    public final /* synthetic */ void zza(zzfn zzfnVar) {
        com.google.android.gms.internal.firebase_auth.zzex zza;
        zzfn zzfnVar2 = zzfnVar;
        if (this.zza.zza("EMAIL")) {
            this.zzb.zza((String) null);
        } else if (this.zza.zzb() != null) {
            this.zzb.zza(this.zza.zzb());
        }
        if (this.zza.zza("DISPLAY_NAME")) {
            this.zzb.zzb(null);
        } else if (this.zza.zzd() != null) {
            this.zzb.zzb(this.zza.zzd());
        }
        if (this.zza.zza("PHOTO_URL")) {
            this.zzb.zzc(null);
        } else if (this.zza.zze() != null) {
            this.zzb.zzc(this.zza.zze());
        }
        if (!TextUtils.isEmpty(this.zza.zzc())) {
            this.zzb.zzd(Base64Utils.encode("redacted".getBytes()));
        }
        List<com.google.android.gms.internal.firebase_auth.zzfb> zzf = zzfnVar2.zzf();
        if (zzf == null) {
            zzf = new ArrayList<>();
        }
        this.zzb.zza(zzf);
        zzds zzdsVar = this.zzc;
        zzb zzbVar = this.zzf;
        zza = zzb.zza(this.zzd, zzfnVar2);
        zzdsVar.zza(zza, this.zzb);
    }
}
