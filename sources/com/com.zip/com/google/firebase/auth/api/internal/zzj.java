package com.google.firebase.auth.api.internal;

import android.text.TextUtils;
import androidx.annotation.Nullable;
import com.google.android.gms.internal.firebase_auth.zzep;
import java.util.List;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public final class zzj implements zzff<zzep> {
    private final /* synthetic */ zzfc zza;
    private final /* synthetic */ String zzb;
    private final /* synthetic */ String zzc;
    private final /* synthetic */ Boolean zzd;
    private final /* synthetic */ com.google.firebase.auth.zzg zze;
    private final /* synthetic */ zzds zzf;
    private final /* synthetic */ com.google.android.gms.internal.firebase_auth.zzex zzg;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzj(zzb zzbVar, zzfc zzfcVar, String str, String str2, Boolean bool, com.google.firebase.auth.zzg zzgVar, zzds zzdsVar, com.google.android.gms.internal.firebase_auth.zzex zzexVar) {
        this.zza = zzfcVar;
        this.zzb = str;
        this.zzc = str2;
        this.zzd = bool;
        this.zze = zzgVar;
        this.zzf = zzdsVar;
        this.zzg = zzexVar;
    }

    @Override // com.google.firebase.auth.api.internal.zzfc
    public final void zza(@Nullable String str) {
        this.zza.zza(str);
    }

    @Override // com.google.firebase.auth.api.internal.zzff
    public final /* synthetic */ void zza(zzep zzepVar) {
        boolean z = false;
        List<com.google.android.gms.internal.firebase_auth.zzer> zzb = zzepVar.zzb();
        if (zzb == null || zzb.isEmpty()) {
            this.zza.zza("No users.");
            return;
        }
        com.google.android.gms.internal.firebase_auth.zzer zzerVar = zzb.get(0);
        com.google.android.gms.internal.firebase_auth.zzfd zzk = zzerVar.zzk();
        List<com.google.android.gms.internal.firebase_auth.zzfb> zza = zzk != null ? zzk.zza() : null;
        if (zza != null && !zza.isEmpty()) {
            if (!TextUtils.isEmpty(this.zzb)) {
                int i = 0;
                while (true) {
                    if (i >= zza.size()) {
                        break;
                    } else if (zza.get(i).zzd().equals(this.zzb)) {
                        zza.get(i).zza(this.zzc);
                        break;
                    } else {
                        i++;
                    }
                }
            } else {
                zza.get(0).zza(this.zzc);
            }
        }
        if (this.zzd != null) {
            zzerVar.zza(this.zzd.booleanValue());
        } else {
            if (zzerVar.zzh() - zzerVar.zzg() < 1000) {
                z = true;
            }
            zzerVar.zza(z);
        }
        zzerVar.zza(this.zze);
        this.zzf.zza(this.zzg, zzerVar);
    }
}
