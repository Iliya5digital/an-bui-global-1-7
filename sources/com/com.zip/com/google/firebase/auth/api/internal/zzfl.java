package com.google.firebase.auth.api.internal;

import com.google.android.gms.internal.firebase_auth.zzjf;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public interface zzfl<T extends zzjf> {
    T zza();
}
