package com.google.firebase.auth.api.internal;

import android.os.RemoteException;
import androidx.annotation.Nullable;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.common.util.VisibleForTesting;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.PhoneAuthCredential;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
@VisibleForTesting
/* loaded from: classes57.dex */
public final class zzev extends zzed {
    final /* synthetic */ zzet zza;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzev(zzet zzetVar) {
        this.zza = zzetVar;
    }

    @Override // com.google.firebase.auth.api.internal.zzea
    public final void zza(com.google.android.gms.internal.firebase_auth.zzex zzexVar) throws RemoteException {
        boolean z = true;
        if (this.zza.zzb != 1) {
            z = false;
        }
        Preconditions.checkState(z, new StringBuilder(37).append("Unexpected response type: ").append(this.zza.zzb).toString());
        this.zza.zzk = zzexVar;
        this.zza.zzf();
    }

    @Override // com.google.firebase.auth.api.internal.zzea
    public final void zza(com.google.android.gms.internal.firebase_auth.zzex zzexVar, com.google.android.gms.internal.firebase_auth.zzer zzerVar) throws RemoteException {
        Preconditions.checkState(this.zza.zzb == 2, new StringBuilder(37).append("Unexpected response type: ").append(this.zza.zzb).toString());
        this.zza.zzk = zzexVar;
        this.zza.zzl = zzerVar;
        this.zza.zzf();
    }

    @Override // com.google.firebase.auth.api.internal.zzea
    public final void zza(com.google.android.gms.internal.firebase_auth.zzeh zzehVar) throws RemoteException {
        Preconditions.checkState(this.zza.zzb == 3, new StringBuilder(36).append("Unexpected response type ").append(this.zza.zzb).toString());
        this.zza.zzm = zzehVar;
        this.zza.zzf();
    }

    @Override // com.google.firebase.auth.api.internal.zzea
    public final void zza(@Nullable com.google.android.gms.internal.firebase_auth.zzfe zzfeVar) throws RemoteException {
        Preconditions.checkState(this.zza.zzb == 4, new StringBuilder(36).append("Unexpected response type ").append(this.zza.zzb).toString());
        this.zza.zzn = zzfeVar;
        this.zza.zzf();
    }

    @Override // com.google.firebase.auth.api.internal.zzea
    public final void a_() throws RemoteException {
        Preconditions.checkState(this.zza.zzb == 5, new StringBuilder(36).append("Unexpected response type ").append(this.zza.zzb).toString());
        this.zza.zzf();
    }

    @Override // com.google.firebase.auth.api.internal.zzea
    public final void zzb() throws RemoteException {
        Preconditions.checkState(this.zza.zzb == 6, new StringBuilder(36).append("Unexpected response type ").append(this.zza.zzb).toString());
        this.zza.zzf();
    }

    @Override // com.google.firebase.auth.api.internal.zzea
    public final void zza(String str) throws RemoteException {
        Preconditions.checkState(this.zza.zzb == 7, new StringBuilder(36).append("Unexpected response type ").append(this.zza.zzb).toString());
        this.zza.zzo = str;
        this.zza.zzf();
    }

    @Override // com.google.firebase.auth.api.internal.zzea
    public final void zzb(String str) throws RemoteException {
        Preconditions.checkState(this.zza.zzb == 8, new StringBuilder(36).append("Unexpected response type ").append(this.zza.zzb).toString());
        this.zza.zzp = str;
        zza(new zzeu(this, str));
    }

    @Override // com.google.firebase.auth.api.internal.zzea
    public final void zza(PhoneAuthCredential phoneAuthCredential) throws RemoteException {
        Preconditions.checkState(this.zza.zzb == 8, new StringBuilder(36).append("Unexpected response type ").append(this.zza.zzb).toString());
        this.zza.zzx = true;
        this.zza.zzw = true;
        zza(new zzex(this, phoneAuthCredential));
    }

    @Override // com.google.firebase.auth.api.internal.zzea
    public final void zzc(String str) throws RemoteException {
        Preconditions.checkState(this.zza.zzb == 8, new StringBuilder(36).append("Unexpected response type ").append(this.zza.zzb).toString());
        this.zza.zzp = str;
        this.zza.zzx = true;
        this.zza.zzw = true;
        zza(new zzew(this, str));
    }

    @Override // com.google.firebase.auth.api.internal.zzea
    public final void zza(Status status) throws RemoteException {
        String statusMessage = status.getStatusMessage();
        if (statusMessage != null) {
            if (statusMessage.contains("MISSING_MFA_PENDING_CREDENTIAL")) {
                status = new Status(17081);
            } else if (statusMessage.contains("MISSING_MFA_ENROLLMENT_ID")) {
                status = new Status(17082);
            } else if (statusMessage.contains("INVALID_MFA_PENDING_CREDENTIAL")) {
                status = new Status(17083);
            } else if (statusMessage.contains("MFA_ENROLLMENT_NOT_FOUND")) {
                status = new Status(17084);
            } else if (statusMessage.contains("ADMIN_ONLY_OPERATION")) {
                status = new Status(17085);
            } else if (statusMessage.contains("UNVERIFIED_EMAIL")) {
                status = new Status(17086);
            } else if (statusMessage.contains("SECOND_FACTOR_EXISTS")) {
                status = new Status(17087);
            } else if (statusMessage.contains("SECOND_FACTOR_LIMIT_EXCEEDED")) {
                status = new Status(17088);
            } else if (statusMessage.contains("UNSUPPORTED_FIRST_FACTOR")) {
                status = new Status(17089);
            } else if (statusMessage.contains("EMAIL_CHANGE_NEEDS_VERIFICATION")) {
                status = new Status(17090);
            }
        }
        if (this.zza.zzb == 8) {
            this.zza.zzx = true;
            this.zza.zzw = false;
            zza(new zzez(this, status));
            return;
        }
        this.zza.zzb(status);
        this.zza.zza(status);
    }

    @Override // com.google.firebase.auth.api.internal.zzea
    public final void zza(Status status, PhoneAuthCredential phoneAuthCredential) throws RemoteException {
        Preconditions.checkState(this.zza.zzb == 2, new StringBuilder(36).append("Unexpected response type ").append(this.zza.zzb).toString());
        zza(status, phoneAuthCredential, (String) null, (String) null);
    }

    @Override // com.google.firebase.auth.api.internal.zzea
    public final void zza(com.google.android.gms.internal.firebase_auth.zzec zzecVar) {
        zza(zzecVar.zza(), zzecVar.zzb(), zzecVar.zzc(), zzecVar.zzd());
    }

    @Override // com.google.firebase.auth.api.internal.zzea
    public final void zza(com.google.android.gms.internal.firebase_auth.zzee zzeeVar) {
        this.zza.zzt = zzeeVar;
        this.zza.zza(com.google.firebase.auth.internal.zzy.zza("REQUIRES_SECOND_FACTOR_AUTH"));
    }

    private final void zza(Status status, AuthCredential authCredential, @Nullable String str, @Nullable String str2) {
        this.zza.zzb(status);
        this.zza.zzq = authCredential;
        this.zza.zzr = str;
        this.zza.zzs = str2;
        if (this.zza.zzg != null) {
            this.zza.zzg.zza(status);
        }
        this.zza.zza(status);
    }

    @Override // com.google.firebase.auth.api.internal.zzea
    public final void zzc() throws RemoteException {
        Preconditions.checkState(this.zza.zzb == 9, new StringBuilder(36).append("Unexpected response type ").append(this.zza.zzb).toString());
        this.zza.zzf();
    }

    private final void zza(zzfb zzfbVar) {
        this.zza.zzj.execute(new zzey(this, zzfbVar));
    }
}
