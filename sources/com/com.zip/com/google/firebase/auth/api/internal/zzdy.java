package com.google.firebase.auth.api.internal;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public final class zzdy {
    public static final Boolean zza = true;
    public static final Boolean zzb = true;
}
