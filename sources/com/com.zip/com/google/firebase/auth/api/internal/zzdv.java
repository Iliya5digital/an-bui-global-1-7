package com.google.firebase.auth.api.internal;

import android.os.DeadObjectException;
import com.google.android.gms.common.api.Api;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public interface zzdv extends Api.Client {
    zzef zza() throws DeadObjectException;
}
