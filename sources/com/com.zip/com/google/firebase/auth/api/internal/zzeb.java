package com.google.firebase.auth.api.internal;

import com.google.android.gms.internal.firebase_auth.zzjf;
import com.google.android.gms.internal.firebase_auth.zzjp;
import com.google.firebase.auth.api.internal.zzeb;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public interface zzeb<WrapperT extends zzeb<?, ?>, ProtoT extends zzjf> {
    zzjp<ProtoT> zza();

    WrapperT zza(zzjf zzjfVar);
}
