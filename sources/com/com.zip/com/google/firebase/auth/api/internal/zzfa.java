package com.google.firebase.auth.api.internal;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public final class zzfa<ResultT, CallbackT> implements zzer<ResultT> {
    private final zzet<ResultT, CallbackT> zza;
    private final TaskCompletionSource<ResultT> zzb;

    public zzfa(zzet<ResultT, CallbackT> zzetVar, TaskCompletionSource<ResultT> taskCompletionSource) {
        this.zza = zzetVar;
        this.zzb = taskCompletionSource;
    }

    @Override // com.google.firebase.auth.api.internal.zzer
    public final void zza(ResultT resultt, Status status) {
        FirebaseUser firebaseUser;
        Preconditions.checkNotNull(this.zzb, "completion source cannot be null");
        if (status != null) {
            if (this.zza.zzt != null) {
                TaskCompletionSource<ResultT> taskCompletionSource = this.zzb;
                FirebaseAuth firebaseAuth = FirebaseAuth.getInstance(this.zza.zzd);
                com.google.android.gms.internal.firebase_auth.zzee zzeeVar = this.zza.zzt;
                if ("reauthenticateWithCredential".equals(this.zza.zza()) || "reauthenticateWithCredentialWithData".equals(this.zza.zza())) {
                    firebaseUser = this.zza.zze;
                } else {
                    firebaseUser = null;
                }
                taskCompletionSource.setException(zzdx.zza(firebaseAuth, zzeeVar, firebaseUser));
                return;
            } else if (this.zza.zzq != null) {
                this.zzb.setException(zzdx.zza(status, this.zza.zzq, this.zza.zzr, this.zza.zzs));
                return;
            } else {
                this.zzb.setException(zzdx.zza(status));
                return;
            }
        }
        this.zzb.setResult(resultt);
    }
}
