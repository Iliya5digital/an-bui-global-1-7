package com.google.firebase.auth.api.internal;

import com.google.android.gms.common.api.Status;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
interface zzer<ResultT> {
    void zza(ResultT resultt, Status status);
}
