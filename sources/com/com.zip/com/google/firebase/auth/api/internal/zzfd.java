package com.google.firebase.auth.api.internal;

import android.content.Context;
import androidx.annotation.Nullable;
import com.google.android.gms.internal.firebase_auth.zzel;
import com.google.android.gms.internal.firebase_auth.zzen;
import com.google.android.gms.internal.firebase_auth.zzep;
import com.google.android.gms.internal.firebase_auth.zzfk;
import com.google.android.gms.internal.firebase_auth.zzfm;
import com.google.android.gms.internal.firebase_auth.zzfn;
import com.google.android.gms.internal.firebase_auth.zzfp;
import com.google.android.gms.internal.firebase_auth.zzfq;
import com.google.android.gms.internal.firebase_auth.zzfs;
import com.google.android.gms.internal.firebase_auth.zzfu;
import com.google.android.gms.internal.firebase_auth.zzfv;
import com.google.android.gms.internal.firebase_auth.zzfw;
import com.google.android.gms.internal.firebase_auth.zzfy;
import com.google.android.gms.internal.firebase_auth.zzfz;
import com.google.android.gms.internal.firebase_auth.zzga;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public abstract class zzfd {
    public abstract void zza(@Nullable Context context, zzfq zzfqVar, zzff<zzfs> zzffVar);

    public abstract void zza(Context context, zzfw zzfwVar, zzff<zzfz> zzffVar);

    public abstract void zza(Context context, zzfy zzfyVar, zzff<zzga> zzffVar);

    public abstract void zza(com.google.android.gms.internal.firebase_auth.zzef zzefVar, zzff<com.google.android.gms.internal.firebase_auth.zzeh> zzffVar);

    public abstract void zza(com.google.android.gms.internal.firebase_auth.zzei zzeiVar, zzff<zzel> zzffVar);

    public abstract void zza(com.google.android.gms.internal.firebase_auth.zzej zzejVar, zzff<Void> zzffVar);

    public abstract void zza(com.google.android.gms.internal.firebase_auth.zzem zzemVar, zzff<zzep> zzffVar);

    public abstract void zza(zzen zzenVar, zzff<com.google.android.gms.internal.firebase_auth.zzex> zzffVar);

    public abstract void zza(com.google.android.gms.internal.firebase_auth.zzev zzevVar, zzff<Object> zzffVar);

    public abstract void zza(com.google.android.gms.internal.firebase_auth.zzff zzffVar, zzff<com.google.android.gms.internal.firebase_auth.zzfe> zzffVar2);

    public abstract void zza(com.google.android.gms.internal.firebase_auth.zzfj zzfjVar, zzff<com.google.android.gms.internal.firebase_auth.zzfl> zzffVar);

    public abstract void zza(zzfk zzfkVar, zzff<zzfn> zzffVar);

    public abstract void zza(zzfm zzfmVar, zzff<zzfp> zzffVar);

    public abstract void zza(zzfv zzfvVar, zzff<zzfu> zzffVar);

    public abstract void zza(@Nullable String str, zzff<Void> zzffVar);
}
