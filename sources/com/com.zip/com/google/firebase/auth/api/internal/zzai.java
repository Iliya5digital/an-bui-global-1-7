package com.google.firebase.auth.api.internal;

import androidx.annotation.Nullable;
import com.google.android.gms.internal.firebase_auth.zzfn;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
final class zzai implements zzff<zzfn> {
    private final /* synthetic */ zzds zza;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzai(zzb zzbVar, zzds zzdsVar) {
        this.zza = zzdsVar;
    }

    @Override // com.google.firebase.auth.api.internal.zzfc
    public final void zza(@Nullable String str) {
        this.zza.zza(com.google.firebase.auth.internal.zzy.zza(str));
    }

    @Override // com.google.firebase.auth.api.internal.zzff
    public final /* synthetic */ void zza(zzfn zzfnVar) {
        this.zza.zza(zzfnVar.zze());
    }
}
