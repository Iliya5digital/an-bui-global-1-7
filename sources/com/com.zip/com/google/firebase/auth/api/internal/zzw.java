package com.google.firebase.auth.api.internal;

import androidx.annotation.Nullable;
import com.google.android.gms.internal.firebase_auth.zzep;
import com.google.android.gms.internal.firebase_auth.zzfk;
import java.util.List;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
final class zzw implements zzff<zzep> {
    private final /* synthetic */ zzff zza;
    private final /* synthetic */ com.google.android.gms.internal.firebase_auth.zzex zzb;
    private final /* synthetic */ zzx zzc;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzw(zzx zzxVar, zzff zzffVar, com.google.android.gms.internal.firebase_auth.zzex zzexVar) {
        this.zzc = zzxVar;
        this.zza = zzffVar;
        this.zzb = zzexVar;
    }

    @Override // com.google.firebase.auth.api.internal.zzfc
    public final void zza(@Nullable String str) {
        this.zzc.zzb.zza(com.google.firebase.auth.internal.zzy.zza(str));
    }

    @Override // com.google.firebase.auth.api.internal.zzff
    public final /* synthetic */ void zza(zzep zzepVar) {
        List<com.google.android.gms.internal.firebase_auth.zzer> zzb = zzepVar.zzb();
        if (zzb == null || zzb.isEmpty()) {
            this.zza.zza("No users.");
            return;
        }
        zzfk zzfkVar = new zzfk();
        zzfkVar.zzb(this.zzb.zzd()).zzg(this.zzc.zza);
        this.zzc.zzc.zza(this.zzc.zzb, this.zzb, zzb.get(0), zzfkVar, this.zza);
    }
}
