package com.google.firebase.auth.api.internal;

import androidx.annotation.Nullable;
import com.google.android.gms.internal.firebase_auth.zzfu;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
final class zzn implements zzff<zzfu> {
    private final /* synthetic */ zzds zza;
    private final /* synthetic */ zzb zzb;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzn(zzb zzbVar, zzds zzdsVar) {
        this.zzb = zzbVar;
        this.zza = zzdsVar;
    }

    @Override // com.google.firebase.auth.api.internal.zzfc
    public final void zza(@Nullable String str) {
        this.zza.zza(com.google.firebase.auth.internal.zzy.zza(str));
    }

    @Override // com.google.firebase.auth.api.internal.zzff
    public final /* synthetic */ void zza(zzfu zzfuVar) {
        zzfu zzfuVar2 = zzfuVar;
        this.zzb.zza(new com.google.android.gms.internal.firebase_auth.zzex(zzfuVar2.zzc(), zzfuVar2.zzb(), Long.valueOf(zzfuVar2.zzd()), "Bearer"), null, null, Boolean.valueOf(zzfuVar2.zze()), null, this.zza, this);
    }
}
