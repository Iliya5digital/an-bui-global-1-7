package com.google.firebase.auth.api.internal;

import androidx.annotation.Nullable;
import com.google.android.gms.internal.firebase_auth.zzfk;
import com.google.firebase.auth.UserProfileChangeRequest;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
final class zzah implements zzff<com.google.android.gms.internal.firebase_auth.zzex> {
    private final /* synthetic */ UserProfileChangeRequest zza;
    private final /* synthetic */ zzds zzb;
    private final /* synthetic */ zzb zzc;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzah(zzb zzbVar, UserProfileChangeRequest userProfileChangeRequest, zzds zzdsVar) {
        this.zzc = zzbVar;
        this.zza = userProfileChangeRequest;
        this.zzb = zzdsVar;
    }

    @Override // com.google.firebase.auth.api.internal.zzfc
    public final void zza(@Nullable String str) {
        this.zzb.zza(com.google.firebase.auth.internal.zzy.zza(str));
    }

    @Override // com.google.firebase.auth.api.internal.zzff
    public final /* synthetic */ void zza(com.google.android.gms.internal.firebase_auth.zzex zzexVar) {
        com.google.android.gms.internal.firebase_auth.zzex zzexVar2 = zzexVar;
        zzfk zzfkVar = new zzfk();
        zzfkVar.zzb(zzexVar2.zzd());
        if (this.zza.zzb() || this.zza.getDisplayName() != null) {
            zzfkVar.zze(this.zza.getDisplayName());
        }
        if (this.zza.zzc() || this.zza.getPhotoUri() != null) {
            zzfkVar.zzf(this.zza.zza());
        }
        this.zzc.zza(this.zzb, zzexVar2, zzfkVar, this);
    }
}
