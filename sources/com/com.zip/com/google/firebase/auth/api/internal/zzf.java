package com.google.firebase.auth.api.internal;

import androidx.annotation.Nullable;
import com.google.firebase.auth.EmailAuthCredential;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
final class zzf implements zzff<com.google.android.gms.internal.firebase_auth.zzex> {
    private final /* synthetic */ EmailAuthCredential zza;
    private final /* synthetic */ zzds zzb;
    private final /* synthetic */ zzb zzc;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzf(zzb zzbVar, EmailAuthCredential emailAuthCredential, zzds zzdsVar) {
        this.zzc = zzbVar;
        this.zza = emailAuthCredential;
        this.zzb = zzdsVar;
    }

    @Override // com.google.firebase.auth.api.internal.zzfc
    public final void zza(@Nullable String str) {
        this.zzb.zza(com.google.firebase.auth.internal.zzy.zza(str));
    }

    @Override // com.google.firebase.auth.api.internal.zzff
    public final /* synthetic */ void zza(com.google.android.gms.internal.firebase_auth.zzex zzexVar) {
        this.zzc.zza(new com.google.android.gms.internal.firebase_auth.zzei(this.zza, zzexVar.zzd()), this.zzb);
    }
}
