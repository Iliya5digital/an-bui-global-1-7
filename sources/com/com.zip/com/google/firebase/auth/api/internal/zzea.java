package com.google.firebase.auth.api.internal;

import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.common.api.Status;
import com.google.firebase.auth.PhoneAuthCredential;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public interface zzea extends IInterface {
    void a_() throws RemoteException;

    void zza(Status status) throws RemoteException;

    void zza(Status status, PhoneAuthCredential phoneAuthCredential) throws RemoteException;

    void zza(com.google.android.gms.internal.firebase_auth.zzec zzecVar) throws RemoteException;

    void zza(com.google.android.gms.internal.firebase_auth.zzee zzeeVar) throws RemoteException;

    void zza(com.google.android.gms.internal.firebase_auth.zzeh zzehVar) throws RemoteException;

    void zza(com.google.android.gms.internal.firebase_auth.zzex zzexVar) throws RemoteException;

    void zza(com.google.android.gms.internal.firebase_auth.zzex zzexVar, com.google.android.gms.internal.firebase_auth.zzer zzerVar) throws RemoteException;

    void zza(com.google.android.gms.internal.firebase_auth.zzfe zzfeVar) throws RemoteException;

    void zza(PhoneAuthCredential phoneAuthCredential) throws RemoteException;

    void zza(String str) throws RemoteException;

    void zzb() throws RemoteException;

    void zzb(String str) throws RemoteException;

    void zzc() throws RemoteException;

    void zzc(String str) throws RemoteException;
}
