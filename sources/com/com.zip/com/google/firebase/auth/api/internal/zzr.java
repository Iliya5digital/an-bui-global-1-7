package com.google.firebase.auth.api.internal;

import androidx.annotation.Nullable;
import com.google.android.gms.internal.firebase_auth.zzfk;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
final class zzr implements zzff<com.google.android.gms.internal.firebase_auth.zzex> {
    private final /* synthetic */ String zza;
    private final /* synthetic */ String zzb;
    private final /* synthetic */ zzds zzc;
    private final /* synthetic */ zzb zzd;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzr(zzb zzbVar, String str, String str2, zzds zzdsVar) {
        this.zzd = zzbVar;
        this.zza = str;
        this.zzb = str2;
        this.zzc = zzdsVar;
    }

    @Override // com.google.firebase.auth.api.internal.zzfc
    public final void zza(@Nullable String str) {
        this.zzc.zza(com.google.firebase.auth.internal.zzy.zza(str));
    }

    @Override // com.google.firebase.auth.api.internal.zzff
    public final /* synthetic */ void zza(com.google.android.gms.internal.firebase_auth.zzex zzexVar) {
        com.google.android.gms.internal.firebase_auth.zzex zzexVar2 = zzexVar;
        zzfk zzfkVar = new zzfk();
        zzfkVar.zzb(zzexVar2.zzd()).zzc(this.zza).zzd(this.zzb);
        this.zzd.zza(this.zzc, zzexVar2, zzfkVar, this);
    }
}
