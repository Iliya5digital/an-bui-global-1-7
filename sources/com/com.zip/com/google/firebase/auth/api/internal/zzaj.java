package com.google.firebase.auth.api.internal;

import androidx.annotation.Nullable;
import com.google.android.gms.internal.firebase_auth.zzfk;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
final class zzaj implements zzff<com.google.android.gms.internal.firebase_auth.zzex> {
    private final /* synthetic */ String zza;
    private final /* synthetic */ zzds zzb;
    private final /* synthetic */ zzb zzc;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzaj(zzb zzbVar, String str, zzds zzdsVar) {
        this.zzc = zzbVar;
        this.zza = str;
        this.zzb = zzdsVar;
    }

    @Override // com.google.firebase.auth.api.internal.zzfc
    public final void zza(@Nullable String str) {
        this.zzb.zza(com.google.firebase.auth.internal.zzy.zza(str));
    }

    @Override // com.google.firebase.auth.api.internal.zzff
    public final /* synthetic */ void zza(com.google.android.gms.internal.firebase_auth.zzex zzexVar) {
        com.google.android.gms.internal.firebase_auth.zzex zzexVar2 = zzexVar;
        String zzd = zzexVar2.zzd();
        zzfk zzfkVar = new zzfk();
        zzfkVar.zzb(zzd).zzd(this.zza);
        this.zzc.zza(this.zzb, zzexVar2, zzfkVar, this);
    }
}
