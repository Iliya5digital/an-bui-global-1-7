package com.google.firebase.auth.api.internal;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public final class zzaf implements zzff<Object> {
    private final /* synthetic */ zzds zza;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzaf(zzb zzbVar, zzds zzdsVar) {
        this.zza = zzdsVar;
    }

    @Override // com.google.firebase.auth.api.internal.zzfc
    public final void zza(String str) {
        this.zza.zza(com.google.firebase.auth.internal.zzy.zza(str));
    }

    @Override // com.google.firebase.auth.api.internal.zzff
    public final /* synthetic */ void zza(Object obj) {
        this.zza.zzb();
    }
}
