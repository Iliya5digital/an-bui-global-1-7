package com.google.firebase.auth.api.internal;

import android.text.TextUtils;
import com.google.android.gms.common.internal.LibraryVersion;
import java.util.Iterator;
import java.util.List;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public final class zzem {
    private final int zza;
    private final int zzb = -1;

    private zzem(String str, int i) {
        this.zza = zzc(str);
    }

    public final boolean zza() {
        return this.zza >= zzc("16.2.1");
    }

    public final boolean zza(String str) {
        return this.zza >= zzc(str);
    }

    public static String zzb() {
        return zzb("firebase-auth");
    }

    private static String zzb(String str) {
        String version = LibraryVersion.getInstance().getVersion(str);
        if (TextUtils.isEmpty(version) || version.equals("UNKNOWN")) {
            return "-1";
        }
        return version;
    }

    public static zzem zzc() {
        return new zzem(zzb("firebase-auth-compat"), -1);
    }

    private static int zzc(String str) {
        List<String> zza = com.google.android.gms.internal.firebase_auth.zzan.zza(".").zza((CharSequence) str);
        if (zza.size() == 1) {
            return Integer.parseInt(str);
        }
        if (zza.size() == 3) {
            return Integer.parseInt(zza.get(2)) + (1000000 * Integer.parseInt(zza.get(0))) + (Integer.parseInt(zza.get(1)) * 1000);
        }
        String str2 = "";
        Iterator<String> it = zza.iterator();
        while (true) {
            String str3 = str2;
            if (it.hasNext()) {
                String valueOf = String.valueOf(str3);
                String valueOf2 = String.valueOf(it.next());
                str2 = valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf);
            } else {
                return Integer.parseInt(str3);
            }
        }
    }
}
