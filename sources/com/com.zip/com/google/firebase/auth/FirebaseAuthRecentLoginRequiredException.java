package com.google.firebase.auth;

import androidx.annotation.NonNull;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public final class FirebaseAuthRecentLoginRequiredException extends FirebaseAuthException {
    public FirebaseAuthRecentLoginRequiredException(@NonNull String str, @NonNull String str2) {
        super(str, str2);
    }
}
