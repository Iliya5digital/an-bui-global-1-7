package com.google.firebase.auth.internal;

import android.app.Application;
import android.content.Context;
import com.google.android.gms.common.api.internal.BackgroundDetector;
import com.google.android.gms.common.util.VisibleForTesting;
import com.google.android.gms.internal.firebase_auth.zzex;
import com.google.firebase.FirebaseApp;
/* compiled from: com.google.firebase:firebase-auth@@19.0.0 */
/* loaded from: classes57.dex */
public final class zzau {
    private volatile int zza;
    private final zzaa zzb;
    private volatile boolean zzc;

    public zzau(FirebaseApp firebaseApp) {
        this(firebaseApp.getApplicationContext(), new zzaa(firebaseApp));
    }

    @VisibleForTesting
    private zzau(Context context, zzaa zzaaVar) {
        this.zzc = false;
        this.zza = 0;
        this.zzb = zzaaVar;
        BackgroundDetector.initialize((Application) context.getApplicationContext());
        BackgroundDetector.getInstance().addListener(new zzax(this));
    }

    public final void zza(int i) {
        if (i > 0 && this.zza == 0) {
            this.zza = i;
            if (zzb()) {
                this.zzb.zza();
            }
        } else if (i == 0 && this.zza != 0) {
            this.zzb.zzc();
        }
        this.zza = i;
    }

    public final void zza(zzex zzexVar) {
        if (zzexVar != null) {
            long zze = zzexVar.zze();
            if (zze <= 0) {
                zze = 3600;
            }
            long zzg = (zze * 1000) + zzexVar.zzg();
            zzaa zzaaVar = this.zzb;
            zzaaVar.zza = zzg;
            zzaaVar.zzb = -1L;
            if (zzb()) {
                this.zzb.zza();
            }
        }
    }

    public final void zza() {
        this.zzb.zzc();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final boolean zzb() {
        return this.zza > 0 && !this.zzc;
    }
}
