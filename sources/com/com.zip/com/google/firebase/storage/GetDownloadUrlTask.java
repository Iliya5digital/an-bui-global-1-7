package com.google.firebase.storage;

import android.net.Uri;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.firebase.storage.internal.ExponentialBackoffSender;
import com.google.firebase.storage.network.GetMetadataNetworkRequest;
import com.google.firebase.storage.network.NetworkRequest;
import org.json.JSONObject;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: com.google.firebase:firebase-storage@@19.0.0 */
/* loaded from: classes62.dex */
public class GetDownloadUrlTask implements Runnable {
    @NonNull
    private static final String DOWNLOAD_TOKENS_KEY = "downloadTokens";
    private static final String TAG = "GetMetadataTask";
    private TaskCompletionSource<Uri> pendingResult;
    private ExponentialBackoffSender sender;
    private StorageReference storageRef;

    /* JADX INFO: Access modifiers changed from: package-private */
    public GetDownloadUrlTask(@NonNull StorageReference storageRef, @NonNull TaskCompletionSource<Uri> pendingResult) {
        Preconditions.checkNotNull(storageRef);
        Preconditions.checkNotNull(pendingResult);
        this.storageRef = storageRef;
        this.pendingResult = pendingResult;
        if (storageRef.getRoot().getName().equals(storageRef.getName())) {
            throw new IllegalArgumentException("getDownloadUrl() is not supported at the root of the bucket.");
        }
        FirebaseStorage storage = this.storageRef.getStorage();
        this.sender = new ExponentialBackoffSender(storage.getApp().getApplicationContext(), storage.getAuthProvider(), storage.getMaxOperationRetryTimeMillis());
    }

    private Uri extractDownloadUrl(JSONObject response) {
        String downloadTokens = response.optString(DOWNLOAD_TOKENS_KEY);
        if (!TextUtils.isEmpty(downloadTokens)) {
            String downloadToken = downloadTokens.split(",", -1)[0];
            String baseURL = NetworkRequest.getDefaultURL(this.storageRef.getStorageUri());
            return Uri.parse(baseURL + "?alt=media&token=" + downloadToken);
        }
        return null;
    }

    @Override // java.lang.Runnable
    public void run() {
        NetworkRequest request = new GetMetadataNetworkRequest(this.storageRef.getStorageUri(), this.storageRef.getApp());
        this.sender.sendWithExponentialBackoff(request);
        Uri downloadUrl = null;
        if (request.isResultSuccess()) {
            downloadUrl = extractDownloadUrl(request.getResultBody());
        }
        if (this.pendingResult != null) {
            request.completeTask(this.pendingResult, downloadUrl);
        }
    }
}
