package com.google.firebase.storage;

import android.app.Activity;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.tasks.CancellationToken;
import com.google.android.gms.tasks.CancellationTokenSource;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCanceledListener;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.RuntimeExecutionException;
import com.google.android.gms.tasks.SuccessContinuation;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.firebase.storage.StorageTask.ProvideError;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.concurrent.Executor;
/* compiled from: com.google.firebase:firebase-storage@@19.0.0 */
/* loaded from: classes62.dex */
public abstract class StorageTask<ResultT extends ProvideError> extends ControllableTask<ResultT> {
    static final int INTERNAL_STATE_CANCELED = 256;
    static final int INTERNAL_STATE_CANCELING = 32;
    static final int INTERNAL_STATE_FAILURE = 64;
    static final int INTERNAL_STATE_IN_PROGRESS = 4;
    static final int INTERNAL_STATE_NOT_STARTED = 1;
    static final int INTERNAL_STATE_PAUSED = 16;
    static final int INTERNAL_STATE_PAUSING = 8;
    static final int INTERNAL_STATE_QUEUED = 2;
    static final int INTERNAL_STATE_SUCCESS = 128;
    static final int STATES_CANCELED = 256;
    static final int STATES_COMPLETE = 448;
    static final int STATES_FAILURE = 64;
    static final int STATES_INPROGRESS = -465;
    static final int STATES_PAUSED = 16;
    static final int STATES_SUCCESS = 128;
    private static final String TAG = "StorageTask";
    private ResultT finalResult;
    private static final HashMap<Integer, HashSet<Integer>> ValidUserInitiatedStateChanges = new HashMap<>();
    private static final HashMap<Integer, HashSet<Integer>> ValidTaskInitiatedStateChanges = new HashMap<>();
    @VisibleForTesting
    final TaskListenerImpl<OnProgressListener<? super ResultT>, ResultT> progressManager = new TaskListenerImpl<>(this, STATES_INPROGRESS, StorageTask$$Lambda$7.lambdaFactory$());
    @VisibleForTesting
    final TaskListenerImpl<OnPausedListener<? super ResultT>, ResultT> pausedManager = new TaskListenerImpl<>(this, 16, StorageTask$$Lambda$8.lambdaFactory$());
    protected final Object syncObject = new Object();
    @VisibleForTesting
    final TaskListenerImpl<OnSuccessListener<? super ResultT>, ResultT> successManager = new TaskListenerImpl<>(this, 128, StorageTask$$Lambda$1.lambdaFactory$(this));
    @VisibleForTesting
    final TaskListenerImpl<OnFailureListener, ResultT> failureManager = new TaskListenerImpl<>(this, 64, StorageTask$$Lambda$4.lambdaFactory$(this));
    @VisibleForTesting
    final TaskListenerImpl<OnCompleteListener<ResultT>, ResultT> completeListener = new TaskListenerImpl<>(this, STATES_COMPLETE, StorageTask$$Lambda$5.lambdaFactory$(this));
    @VisibleForTesting
    final TaskListenerImpl<OnCanceledListener, ResultT> cancelManager = new TaskListenerImpl<>(this, 256, StorageTask$$Lambda$6.lambdaFactory$(this));
    private volatile int currentState = 1;

    /* compiled from: com.google.firebase:firebase-storage@@19.0.0 */
    /* loaded from: classes62.dex */
    public interface ProvideError {
        Exception getError();
    }

    @VisibleForTesting
    public abstract StorageReference getStorage();

    @VisibleForTesting
    abstract void run();

    @VisibleForTesting
    abstract void schedule();

    @NonNull
    @VisibleForTesting
    /* renamed from: snapStateImpl */
    abstract ResultT mo451snapStateImpl();

    static {
        ValidUserInitiatedStateChanges.put(1, new HashSet<>(Arrays.asList(16, 256)));
        ValidUserInitiatedStateChanges.put(2, new HashSet<>(Arrays.asList(8, 32)));
        ValidUserInitiatedStateChanges.put(4, new HashSet<>(Arrays.asList(8, 32)));
        ValidUserInitiatedStateChanges.put(16, new HashSet<>(Arrays.asList(2, 256)));
        ValidUserInitiatedStateChanges.put(64, new HashSet<>(Arrays.asList(2, 256)));
        ValidTaskInitiatedStateChanges.put(1, new HashSet<>(Arrays.asList(2, 64)));
        ValidTaskInitiatedStateChanges.put(2, new HashSet<>(Arrays.asList(4, 64, 128)));
        ValidTaskInitiatedStateChanges.put(4, new HashSet<>(Arrays.asList(4, 64, 128)));
        ValidTaskInitiatedStateChanges.put(8, new HashSet<>(Arrays.asList(16, 64, 128)));
        ValidTaskInitiatedStateChanges.put(32, new HashSet<>(Arrays.asList(256, 64, 128)));
    }

    public static /* synthetic */ void lambda$new$0(StorageTask storageTask, OnSuccessListener listener, ProvideError snappedState) {
        StorageTaskManager.getInstance().unRegister(storageTask);
        listener.onSuccess(snappedState);
    }

    public static /* synthetic */ void lambda$new$1(StorageTask storageTask, OnFailureListener listener, ProvideError snappedState) {
        StorageTaskManager.getInstance().unRegister(storageTask);
        listener.onFailure(snappedState.getError());
    }

    public static /* synthetic */ void lambda$new$2(StorageTask storageTask, OnCompleteListener listener, ProvideError snappedState) {
        StorageTaskManager.getInstance().unRegister(storageTask);
        listener.onComplete(storageTask);
    }

    public static /* synthetic */ void lambda$new$3(StorageTask storageTask, OnCanceledListener listener, ProvideError snappedState) {
        StorageTaskManager.getInstance().unRegister(storageTask);
        listener.onCanceled();
    }

    @VisibleForTesting
    public boolean queue() {
        if (tryChangeState(2, false)) {
            schedule();
            return true;
        }
        return false;
    }

    @VisibleForTesting
    void resetState() {
    }

    @Override // com.google.firebase.storage.ControllableTask
    public boolean resume() {
        if (tryChangeState(2, true)) {
            resetState();
            schedule();
            return true;
        }
        return false;
    }

    @Override // com.google.firebase.storage.ControllableTask
    public boolean pause() {
        return tryChangeState(new int[]{16, 8}, true);
    }

    @Override // com.google.firebase.storage.CancellableTask
    public boolean cancel() {
        return tryChangeState(new int[]{256, 32}, true);
    }

    @Override // com.google.android.gms.tasks.Task
    public boolean isComplete() {
        return (getInternalState() & STATES_COMPLETE) != 0;
    }

    @Override // com.google.android.gms.tasks.Task
    public boolean isSuccessful() {
        return (getInternalState() & 128) != 0;
    }

    @Override // com.google.firebase.storage.CancellableTask, com.google.android.gms.tasks.Task
    public boolean isCanceled() {
        return getInternalState() == 256;
    }

    @Override // com.google.firebase.storage.CancellableTask
    public boolean isInProgress() {
        return (getInternalState() & STATES_INPROGRESS) != 0;
    }

    @Override // com.google.firebase.storage.ControllableTask
    public boolean isPaused() {
        return (getInternalState() & 16) != 0;
    }

    @Override // com.google.android.gms.tasks.Task
    @NonNull
    /* renamed from: getResult */
    public ResultT mo447getResult() {
        if (getFinalResult() == null) {
            throw new IllegalStateException();
        }
        Throwable t = getFinalResult().getError();
        if (t != null) {
            throw new RuntimeExecutionException(t);
        }
        return getFinalResult();
    }

    @Override // com.google.android.gms.tasks.Task
    @NonNull
    /* renamed from: getResult */
    public <X extends Throwable> ResultT mo448getResult(@NonNull Class<X> exceptionType) throws Throwable {
        if (getFinalResult() == null) {
            throw new IllegalStateException();
        }
        if (exceptionType.isInstance(getFinalResult().getError())) {
            throw exceptionType.cast(getFinalResult().getError());
        }
        Throwable t = getFinalResult().getError();
        if (t != null) {
            throw new RuntimeExecutionException(t);
        }
        return getFinalResult();
    }

    @Override // com.google.android.gms.tasks.Task
    @Nullable
    public Exception getException() {
        if (getFinalResult() == null) {
            return null;
        }
        return getFinalResult().getError();
    }

    @NonNull
    public ResultT getSnapshot() {
        return snapState();
    }

    @VisibleForTesting
    public int getInternalState() {
        return this.currentState;
    }

    @VisibleForTesting
    public Object getSyncObject() {
        return this.syncObject;
    }

    @NonNull
    @VisibleForTesting
    public ResultT snapState() {
        ResultT mo451snapStateImpl;
        synchronized (this.syncObject) {
            mo451snapStateImpl = mo451snapStateImpl();
        }
        return mo451snapStateImpl;
    }

    @VisibleForTesting
    boolean tryChangeState(int[] requestedStates, boolean userInitiated) {
        boolean z = false;
        HashMap<Integer, HashSet<Integer>> table = userInitiated ? ValidUserInitiatedStateChanges : ValidTaskInitiatedStateChanges;
        synchronized (this.syncObject) {
            int length = requestedStates.length;
            int i = 0;
            while (true) {
                if (i < length) {
                    int newState = requestedStates[i];
                    HashSet<Integer> validStates = table.get(Integer.valueOf(getInternalState()));
                    if (validStates == null || !validStates.contains(Integer.valueOf(newState))) {
                        i++;
                    } else {
                        this.currentState = newState;
                        switch (this.currentState) {
                            case 2:
                                StorageTaskManager.getInstance().ensureRegistered(this);
                                onQueued();
                                break;
                            case 4:
                                onProgress();
                                break;
                            case 16:
                                onPaused();
                                break;
                            case 64:
                                onFailure();
                                break;
                            case 128:
                                onSuccess();
                                break;
                            case 256:
                                onCanceled();
                                break;
                        }
                        this.successManager.onInternalStateChanged();
                        this.failureManager.onInternalStateChanged();
                        this.cancelManager.onInternalStateChanged();
                        this.completeListener.onInternalStateChanged();
                        this.pausedManager.onInternalStateChanged();
                        this.progressManager.onInternalStateChanged();
                        if (Log.isLoggable(TAG, 3)) {
                            Log.d(TAG, "changed internal state to: " + getStateString(newState) + " isUser: " + userInitiated + " from state:" + getStateString(this.currentState));
                        }
                        z = true;
                    }
                } else {
                    Log.w(TAG, "unable to change internal state to: " + getStateString(requestedStates) + " isUser: " + userInitiated + " from state:" + getStateString(this.currentState));
                    break;
                }
            }
        }
        return z;
    }

    @VisibleForTesting
    public boolean tryChangeState(int newState, boolean userInitiated) {
        return tryChangeState(new int[]{newState}, userInitiated);
    }

    protected void onQueued() {
    }

    protected void onProgress() {
    }

    protected void onPaused() {
    }

    protected void onFailure() {
    }

    protected void onSuccess() {
    }

    public void onCanceled() {
    }

    private ResultT getFinalResult() {
        if (this.finalResult != null) {
            return this.finalResult;
        }
        if (!isComplete()) {
            return null;
        }
        if (this.finalResult == null) {
            this.finalResult = snapState();
        }
        return this.finalResult;
    }

    @Override // com.google.firebase.storage.ControllableTask
    @NonNull
    /* renamed from: addOnPausedListener */
    public StorageTask<ResultT> mo439addOnPausedListener(@NonNull OnPausedListener<? super ResultT> listener) {
        Preconditions.checkNotNull(listener);
        this.pausedManager.addListener(null, null, listener);
        return this;
    }

    @Override // com.google.firebase.storage.ControllableTask
    @NonNull
    /* renamed from: addOnPausedListener */
    public StorageTask<ResultT> mo440addOnPausedListener(@NonNull Executor executor, @NonNull OnPausedListener<? super ResultT> listener) {
        Preconditions.checkNotNull(listener);
        Preconditions.checkNotNull(executor);
        this.pausedManager.addListener(null, executor, listener);
        return this;
    }

    @Override // com.google.firebase.storage.ControllableTask
    @NonNull
    /* renamed from: addOnPausedListener */
    public StorageTask<ResultT> mo438addOnPausedListener(@NonNull Activity activity, @NonNull OnPausedListener<? super ResultT> listener) {
        Preconditions.checkNotNull(listener);
        Preconditions.checkNotNull(activity);
        this.pausedManager.addListener(activity, null, listener);
        return this;
    }

    @NonNull
    public StorageTask<ResultT> removeOnPausedListener(@NonNull OnPausedListener<? super ResultT> listener) {
        Preconditions.checkNotNull(listener);
        this.pausedManager.removeListener(listener);
        return this;
    }

    @Override // com.google.firebase.storage.CancellableTask
    @NonNull
    /* renamed from: addOnProgressListener */
    public StorageTask<ResultT> mo442addOnProgressListener(@NonNull OnProgressListener<? super ResultT> listener) {
        Preconditions.checkNotNull(listener);
        this.progressManager.addListener(null, null, listener);
        return this;
    }

    @Override // com.google.firebase.storage.CancellableTask
    @NonNull
    /* renamed from: addOnProgressListener */
    public StorageTask<ResultT> mo443addOnProgressListener(@NonNull Executor executor, @NonNull OnProgressListener<? super ResultT> listener) {
        Preconditions.checkNotNull(listener);
        Preconditions.checkNotNull(executor);
        this.progressManager.addListener(null, executor, listener);
        return this;
    }

    @Override // com.google.firebase.storage.CancellableTask
    @NonNull
    /* renamed from: addOnProgressListener */
    public StorageTask<ResultT> mo441addOnProgressListener(@NonNull Activity activity, @NonNull OnProgressListener<? super ResultT> listener) {
        Preconditions.checkNotNull(listener);
        Preconditions.checkNotNull(activity);
        this.progressManager.addListener(activity, null, listener);
        return this;
    }

    @NonNull
    public StorageTask<ResultT> removeOnProgressListener(@NonNull OnProgressListener<? super ResultT> listener) {
        Preconditions.checkNotNull(listener);
        this.progressManager.removeListener(listener);
        return this;
    }

    @Override // com.google.android.gms.tasks.Task
    @NonNull
    /* renamed from: addOnSuccessListener */
    public StorageTask<ResultT> mo445addOnSuccessListener(@NonNull OnSuccessListener<? super ResultT> listener) {
        Preconditions.checkNotNull(listener);
        this.successManager.addListener(null, null, listener);
        return this;
    }

    @Override // com.google.android.gms.tasks.Task
    @NonNull
    /* renamed from: addOnSuccessListener */
    public StorageTask<ResultT> mo446addOnSuccessListener(@NonNull Executor executor, @NonNull OnSuccessListener<? super ResultT> listener) {
        Preconditions.checkNotNull(executor);
        Preconditions.checkNotNull(listener);
        this.successManager.addListener(null, executor, listener);
        return this;
    }

    @Override // com.google.android.gms.tasks.Task
    @NonNull
    /* renamed from: addOnSuccessListener */
    public StorageTask<ResultT> mo444addOnSuccessListener(@NonNull Activity activity, @NonNull OnSuccessListener<? super ResultT> listener) {
        Preconditions.checkNotNull(activity);
        Preconditions.checkNotNull(listener);
        this.successManager.addListener(activity, null, listener);
        return this;
    }

    @NonNull
    public StorageTask<ResultT> removeOnSuccessListener(@NonNull OnSuccessListener<? super ResultT> listener) {
        Preconditions.checkNotNull(listener);
        this.successManager.removeListener(listener);
        return this;
    }

    @Override // com.google.android.gms.tasks.Task
    @NonNull
    /* renamed from: addOnFailureListener */
    public StorageTask<ResultT> mo436addOnFailureListener(@NonNull OnFailureListener listener) {
        Preconditions.checkNotNull(listener);
        this.failureManager.addListener(null, null, listener);
        return this;
    }

    @Override // com.google.android.gms.tasks.Task
    @NonNull
    /* renamed from: addOnFailureListener */
    public StorageTask<ResultT> mo437addOnFailureListener(@NonNull Executor executor, @NonNull OnFailureListener listener) {
        Preconditions.checkNotNull(listener);
        Preconditions.checkNotNull(executor);
        this.failureManager.addListener(null, executor, listener);
        return this;
    }

    @Override // com.google.android.gms.tasks.Task
    @NonNull
    /* renamed from: addOnFailureListener */
    public StorageTask<ResultT> mo435addOnFailureListener(@NonNull Activity activity, @NonNull OnFailureListener listener) {
        Preconditions.checkNotNull(listener);
        Preconditions.checkNotNull(activity);
        this.failureManager.addListener(activity, null, listener);
        return this;
    }

    @NonNull
    public StorageTask<ResultT> removeOnFailureListener(@NonNull OnFailureListener listener) {
        Preconditions.checkNotNull(listener);
        this.failureManager.removeListener(listener);
        return this;
    }

    @Override // com.google.android.gms.tasks.Task
    @NonNull
    /* renamed from: addOnCompleteListener */
    public StorageTask<ResultT> mo433addOnCompleteListener(@NonNull OnCompleteListener<ResultT> listener) {
        Preconditions.checkNotNull(listener);
        this.completeListener.addListener(null, null, listener);
        return this;
    }

    @Override // com.google.android.gms.tasks.Task
    @NonNull
    /* renamed from: addOnCompleteListener */
    public StorageTask<ResultT> mo434addOnCompleteListener(@NonNull Executor executor, @NonNull OnCompleteListener<ResultT> listener) {
        Preconditions.checkNotNull(listener);
        Preconditions.checkNotNull(executor);
        this.completeListener.addListener(null, executor, listener);
        return this;
    }

    @Override // com.google.android.gms.tasks.Task
    @NonNull
    /* renamed from: addOnCompleteListener */
    public StorageTask<ResultT> mo432addOnCompleteListener(@NonNull Activity activity, @NonNull OnCompleteListener<ResultT> listener) {
        Preconditions.checkNotNull(listener);
        Preconditions.checkNotNull(activity);
        this.completeListener.addListener(activity, null, listener);
        return this;
    }

    @NonNull
    public StorageTask<ResultT> removeOnCompleteListener(@NonNull OnCompleteListener<ResultT> listener) {
        Preconditions.checkNotNull(listener);
        this.completeListener.removeListener(listener);
        return this;
    }

    @Override // com.google.android.gms.tasks.Task
    @NonNull
    /* renamed from: addOnCanceledListener */
    public StorageTask<ResultT> mo430addOnCanceledListener(@NonNull OnCanceledListener listener) {
        Preconditions.checkNotNull(listener);
        this.cancelManager.addListener(null, null, listener);
        return this;
    }

    @Override // com.google.android.gms.tasks.Task
    @NonNull
    /* renamed from: addOnCanceledListener */
    public StorageTask<ResultT> mo431addOnCanceledListener(@NonNull Executor executor, @NonNull OnCanceledListener listener) {
        Preconditions.checkNotNull(listener);
        Preconditions.checkNotNull(executor);
        this.cancelManager.addListener(null, executor, listener);
        return this;
    }

    @Override // com.google.android.gms.tasks.Task
    @NonNull
    /* renamed from: addOnCanceledListener */
    public StorageTask<ResultT> mo429addOnCanceledListener(@NonNull Activity activity, @NonNull OnCanceledListener listener) {
        Preconditions.checkNotNull(listener);
        Preconditions.checkNotNull(activity);
        this.cancelManager.addListener(activity, null, listener);
        return this;
    }

    @NonNull
    public StorageTask<ResultT> removeOnCanceledListener(@NonNull OnCanceledListener listener) {
        Preconditions.checkNotNull(listener);
        this.cancelManager.removeListener(listener);
        return this;
    }

    @Override // com.google.android.gms.tasks.Task
    @NonNull
    public <ContinuationResultT> Task<ContinuationResultT> continueWith(@NonNull Continuation<ResultT, ContinuationResultT> continuation) {
        return continueWithImpl(null, continuation);
    }

    @Override // com.google.android.gms.tasks.Task
    @NonNull
    public <ContinuationResultT> Task<ContinuationResultT> continueWith(@NonNull Executor executor, @NonNull Continuation<ResultT, ContinuationResultT> continuation) {
        return continueWithImpl(executor, continuation);
    }

    @NonNull
    private <ContinuationResultT> Task<ContinuationResultT> continueWithImpl(@Nullable Executor executor, @NonNull Continuation<ResultT, ContinuationResultT> continuation) {
        TaskCompletionSource<ContinuationResultT> source = new TaskCompletionSource<>();
        this.completeListener.addListener(null, executor, StorageTask$$Lambda$9.lambdaFactory$(this, continuation, source));
        return source.getTask();
    }

    /* JADX WARN: Unknown type variable: ContinuationResultT in type: ContinuationResultT */
    public static /* synthetic */ void lambda$continueWithImpl$4(StorageTask storageTask, Continuation continuation, TaskCompletionSource source, Task task) {
        try {
            Object mo428then = continuation.mo428then(storageTask);
            if (!source.getTask().isComplete()) {
                source.setResult(mo428then);
            }
        } catch (RuntimeExecutionException e) {
            if (e.getCause() instanceof Exception) {
                source.setException((Exception) e.getCause());
            } else {
                source.setException(e);
            }
        } catch (Exception e2) {
            source.setException(e2);
        }
    }

    @Override // com.google.android.gms.tasks.Task
    @NonNull
    public <ContinuationResultT> Task<ContinuationResultT> continueWithTask(@NonNull Continuation<ResultT, Task<ContinuationResultT>> continuation) {
        return continueWithTaskImpl(null, continuation);
    }

    @Override // com.google.android.gms.tasks.Task
    @NonNull
    public <ContinuationResultT> Task<ContinuationResultT> continueWithTask(@NonNull Executor executor, @NonNull Continuation<ResultT, Task<ContinuationResultT>> continuation) {
        return continueWithTaskImpl(executor, continuation);
    }

    @Override // com.google.android.gms.tasks.Task
    @NonNull
    public <ContinuationResultT> Task<ContinuationResultT> onSuccessTask(@NonNull SuccessContinuation<ResultT, ContinuationResultT> continuation) {
        return successTaskImpl(null, continuation);
    }

    @Override // com.google.android.gms.tasks.Task
    @NonNull
    public <ContinuationResultT> Task<ContinuationResultT> onSuccessTask(@NonNull Executor executor, @NonNull SuccessContinuation<ResultT, ContinuationResultT> continuation) {
        return successTaskImpl(executor, continuation);
    }

    @NonNull
    private <ContinuationResultT> Task<ContinuationResultT> continueWithTaskImpl(@Nullable Executor executor, @NonNull Continuation<ResultT, Task<ContinuationResultT>> continuation) {
        CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
        CancellationToken cancellationToken = cancellationTokenSource.getToken();
        TaskCompletionSource<ContinuationResultT> source = new TaskCompletionSource<>(cancellationToken);
        this.completeListener.addListener(null, executor, StorageTask$$Lambda$10.lambdaFactory$(this, continuation, source, cancellationTokenSource));
        return source.getTask();
    }

    /* JADX WARN: Unknown type variable: ContinuationResultT in type: com.google.android.gms.tasks.Task<ContinuationResultT> */
    public static /* synthetic */ void lambda$continueWithTaskImpl$5(StorageTask storageTask, Continuation continuation, TaskCompletionSource source, CancellationTokenSource cancellationTokenSource, Task task) {
        try {
            Task task2 = (Task) continuation.mo428then(storageTask);
            if (!source.getTask().isComplete()) {
                if (task2 == null) {
                    source.setException(new NullPointerException("Continuation returned null"));
                    return;
                }
                source.getClass();
                task2.mo445addOnSuccessListener(StorageTask$$Lambda$16.lambdaFactory$(source));
                source.getClass();
                task2.mo436addOnFailureListener(StorageTask$$Lambda$17.lambdaFactory$(source));
                cancellationTokenSource.getClass();
                task2.mo430addOnCanceledListener(StorageTask$$Lambda$18.lambdaFactory$(cancellationTokenSource));
            }
        } catch (RuntimeExecutionException e) {
            if (e.getCause() instanceof Exception) {
                source.setException((Exception) e.getCause());
            } else {
                source.setException(e);
            }
        } catch (Exception e2) {
            source.setException(e2);
        }
    }

    @NonNull
    private <ContinuationResultT> Task<ContinuationResultT> successTaskImpl(@Nullable Executor executor, @NonNull SuccessContinuation<ResultT, ContinuationResultT> continuation) {
        CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
        CancellationToken cancellationToken = cancellationTokenSource.getToken();
        TaskCompletionSource<ContinuationResultT> source = new TaskCompletionSource<>(cancellationToken);
        this.successManager.addListener(null, executor, StorageTask$$Lambda$11.lambdaFactory$(continuation, source, cancellationTokenSource));
        return source.getTask();
    }

    /* JADX WARN: Unknown type variable: ContinuationResultT in type: com.google.android.gms.tasks.Task<ContinuationResultT> */
    public static /* synthetic */ void lambda$successTaskImpl$6(SuccessContinuation continuation, TaskCompletionSource source, CancellationTokenSource cancellationTokenSource, ProvideError result) {
        try {
            Task then = continuation.then(result);
            source.getClass();
            then.mo445addOnSuccessListener(StorageTask$$Lambda$13.lambdaFactory$(source));
            source.getClass();
            then.mo436addOnFailureListener(StorageTask$$Lambda$14.lambdaFactory$(source));
            cancellationTokenSource.getClass();
            then.mo430addOnCanceledListener(StorageTask$$Lambda$15.lambdaFactory$(cancellationTokenSource));
        } catch (RuntimeExecutionException e) {
            if (e.getCause() instanceof Exception) {
                source.setException((Exception) e.getCause());
            } else {
                source.setException(e);
            }
        } catch (Exception e2) {
            source.setException(e2);
        }
    }

    @VisibleForTesting
    public Runnable getRunnable() {
        return StorageTask$$Lambda$12.lambdaFactory$(this);
    }

    public static /* synthetic */ void lambda$getRunnable$7(StorageTask storageTask) {
        try {
            storageTask.run();
        } finally {
            storageTask.ensureFinalState();
        }
    }

    private void ensureFinalState() {
        if (!isComplete() && !isPaused() && getInternalState() != 2 && !tryChangeState(256, false)) {
            tryChangeState(64, false);
        }
    }

    private String getStateString(int[] states) {
        if (states.length == 0) {
            return "";
        }
        StringBuilder builder = new StringBuilder();
        for (int state : states) {
            builder.append(getStateString(state)).append(", ");
        }
        return builder.substring(0, builder.length() - 2);
    }

    private String getStateString(int state) {
        switch (state) {
            case 1:
                return "INTERNAL_STATE_NOT_STARTED";
            case 2:
                return "INTERNAL_STATE_QUEUED";
            case 4:
                return "INTERNAL_STATE_IN_PROGRESS";
            case 8:
                return "INTERNAL_STATE_PAUSING";
            case 16:
                return "INTERNAL_STATE_PAUSED";
            case 32:
                return "INTERNAL_STATE_CANCELING";
            case 64:
                return "INTERNAL_STATE_FAILURE";
            case 128:
                return "INTERNAL_STATE_SUCCESS";
            case 256:
                return "INTERNAL_STATE_CANCELED";
            default:
                return "Unknown Internal State!";
        }
    }

    /* compiled from: com.google.firebase:firebase-storage@@19.0.0 */
    /* loaded from: classes62.dex */
    public class SnapshotBase implements ProvideError {
        private final Exception error;

        public SnapshotBase(@Nullable Exception error) {
            StorageTask.this = this$0;
            if (error == null) {
                if (this$0.isCanceled()) {
                    this.error = StorageException.fromErrorStatus(Status.RESULT_CANCELED);
                    return;
                } else if (this$0.getInternalState() == 64) {
                    this.error = StorageException.fromErrorStatus(Status.RESULT_INTERNAL_ERROR);
                    return;
                } else {
                    this.error = null;
                    return;
                }
            }
            this.error = error;
        }

        @NonNull
        public StorageTask<ResultT> getTask() {
            return StorageTask.this;
        }

        @NonNull
        public StorageReference getStorage() {
            return getTask().getStorage();
        }

        @Override // com.google.firebase.storage.StorageTask.ProvideError
        @Nullable
        public Exception getError() {
            return this.error;
        }
    }
}
