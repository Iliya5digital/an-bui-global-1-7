package com.google.firebase.storage.internal;

import android.os.Handler;
import android.os.Looper;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.android.gms.common.internal.Preconditions;
import com.google.firebase.storage.StorageTaskScheduler;
import java.util.concurrent.Executor;
/* compiled from: com.google.firebase:firebase-storage@@19.0.0 */
/* loaded from: classes62.dex */
public class SmartHandler {
    static boolean testMode = false;
    private final Executor executor;
    private final Handler handler;

    public SmartHandler(@Nullable Executor executor) {
        this.executor = executor;
        if (this.executor == null) {
            if (!testMode) {
                this.handler = new Handler(Looper.getMainLooper());
                return;
            } else {
                this.handler = null;
                return;
            }
        }
        this.handler = null;
    }

    public void callBack(@NonNull Runnable runnable) {
        Preconditions.checkNotNull(runnable);
        if (this.handler == null) {
            if (this.executor != null) {
                this.executor.execute(runnable);
                return;
            } else {
                StorageTaskScheduler.getInstance().scheduleCallback(runnable);
                return;
            }
        }
        this.handler.post(runnable);
    }
}
