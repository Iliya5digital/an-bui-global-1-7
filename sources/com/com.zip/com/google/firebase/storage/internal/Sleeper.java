package com.google.firebase.storage.internal;
/* compiled from: com.google.firebase:firebase-storage@@19.0.0 */
/* loaded from: classes62.dex */
public interface Sleeper {
    void sleep(int i) throws InterruptedException;
}
