package com.google.firebase.storage.internal;

import android.net.Uri;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.android.gms.common.internal.Preconditions;
import java.io.UnsupportedEncodingException;
/* compiled from: com.google.firebase:firebase-storage@@19.0.0 */
/* loaded from: classes62.dex */
public class Slashes {
    @NonNull
    public static String preserveSlashEncode(@Nullable String s) throws UnsupportedEncodingException {
        return TextUtils.isEmpty(s) ? "" : slashize(Uri.encode(s));
    }

    @NonNull
    public static String slashize(@NonNull String s) {
        Preconditions.checkNotNull(s);
        return s.replace("%2F", "/");
    }

    @NonNull
    public static String unSlashize(@NonNull String s) {
        Preconditions.checkNotNull(s);
        return s.replace("/", "%2F");
    }

    @NonNull
    public static String normalizeSlashes(@NonNull String uriSegment) {
        String[] split;
        if (TextUtils.isEmpty(uriSegment)) {
            return "";
        }
        if (uriSegment.startsWith("/") || uriSegment.endsWith("/") || uriSegment.contains("//")) {
            StringBuilder result = new StringBuilder();
            for (String stringSegment : uriSegment.split("/", -1)) {
                if (!TextUtils.isEmpty(stringSegment)) {
                    if (result.length() > 0) {
                        result.append("/").append(stringSegment);
                    } else {
                        result.append(stringSegment);
                    }
                }
            }
            return result.toString();
        }
        return uriSegment;
    }
}
