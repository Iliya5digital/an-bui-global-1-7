package com.google.firebase.storage;

import android.app.Activity;
import androidx.annotation.NonNull;
import com.google.android.gms.tasks.Task;
import java.util.concurrent.Executor;
/* compiled from: com.google.firebase:firebase-storage@@19.0.0 */
/* loaded from: classes62.dex */
public abstract class CancellableTask<StateT> extends Task<StateT> {
    @NonNull
    /* renamed from: addOnProgressListener */
    public abstract CancellableTask<StateT> mo441addOnProgressListener(@NonNull Activity activity, @NonNull OnProgressListener<? super StateT> onProgressListener);

    @NonNull
    /* renamed from: addOnProgressListener */
    public abstract CancellableTask<StateT> mo442addOnProgressListener(@NonNull OnProgressListener<? super StateT> onProgressListener);

    @NonNull
    /* renamed from: addOnProgressListener */
    public abstract CancellableTask<StateT> mo443addOnProgressListener(@NonNull Executor executor, @NonNull OnProgressListener<? super StateT> onProgressListener);

    public abstract boolean cancel();

    @Override // com.google.android.gms.tasks.Task
    public abstract boolean isCanceled();

    public abstract boolean isInProgress();
}
