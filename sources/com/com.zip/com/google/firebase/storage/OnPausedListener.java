package com.google.firebase.storage;

import androidx.annotation.NonNull;
/* compiled from: com.google.firebase:firebase-storage@@19.0.0 */
/* loaded from: classes62.dex */
public interface OnPausedListener<ProgressT> {
    void onPaused(@NonNull ProgressT progresst);
}
