package com.google.firebase.storage;

import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.FirebaseApp;
import com.google.firebase.storage.StreamDownloadTask;
import com.google.firebase.storage.internal.Slashes;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
/* compiled from: com.google.firebase:firebase-storage@@19.0.0 */
/* loaded from: classes62.dex */
public class StorageReference implements Comparable<StorageReference> {
    static final /* synthetic */ boolean $assertionsDisabled;
    private static final String TAG = "StorageReference";
    private final FirebaseStorage mFirebaseStorage;
    private final Uri mStorageUri;

    static {
        $assertionsDisabled = !StorageReference.class.desiredAssertionStatus();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public StorageReference(@NonNull Uri storageUri, @NonNull FirebaseStorage firebaseStorage) {
        boolean z = true;
        Preconditions.checkArgument(storageUri != null, "storageUri cannot be null");
        Preconditions.checkArgument(firebaseStorage == null ? false : z, "FirebaseApp cannot be null");
        this.mStorageUri = storageUri;
        this.mFirebaseStorage = firebaseStorage;
    }

    @NonNull
    public StorageReference child(@NonNull String pathString) {
        Preconditions.checkArgument(!TextUtils.isEmpty(pathString), "childName cannot be null or empty");
        String pathString2 = Slashes.normalizeSlashes(pathString);
        try {
            Uri child = this.mStorageUri.buildUpon().appendEncodedPath(Slashes.preserveSlashEncode(pathString2)).build();
            return new StorageReference(child, this.mFirebaseStorage);
        } catch (UnsupportedEncodingException e) {
            Log.e(TAG, "Unable to create a valid default Uri. " + pathString2, e);
            throw new IllegalArgumentException("childName");
        }
    }

    @Nullable
    public StorageReference getParent() {
        String path;
        String path2 = this.mStorageUri.getPath();
        if (TextUtils.isEmpty(path2) || path2.equals("/")) {
            return null;
        }
        int childIndex = path2.lastIndexOf(47);
        if (childIndex == -1) {
            path = "/";
        } else {
            path = path2.substring(0, childIndex);
        }
        Uri child = this.mStorageUri.buildUpon().path(path).build();
        return new StorageReference(child, this.mFirebaseStorage);
    }

    @NonNull
    public StorageReference getRoot() {
        Uri child = this.mStorageUri.buildUpon().path("").build();
        return new StorageReference(child, this.mFirebaseStorage);
    }

    @NonNull
    public String getName() {
        String path = this.mStorageUri.getPath();
        if ($assertionsDisabled || path != null) {
            int lastIndex = path.lastIndexOf(47);
            if (lastIndex != -1) {
                return path.substring(lastIndex + 1);
            }
            return path;
        }
        throw new AssertionError();
    }

    @NonNull
    public String getPath() {
        String path = this.mStorageUri.getPath();
        if ($assertionsDisabled || path != null) {
            return path;
        }
        throw new AssertionError();
    }

    @NonNull
    public String getBucket() {
        return this.mStorageUri.getAuthority();
    }

    @NonNull
    public FirebaseStorage getStorage() {
        return this.mFirebaseStorage;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @NonNull
    public FirebaseApp getApp() {
        return getStorage().getApp();
    }

    @NonNull
    public UploadTask putBytes(@NonNull byte[] bytes) {
        Preconditions.checkArgument(bytes != null, "bytes cannot be null");
        UploadTask task = new UploadTask(this, (StorageMetadata) null, bytes);
        task.queue();
        return task;
    }

    @NonNull
    public UploadTask putBytes(@NonNull byte[] bytes, @NonNull StorageMetadata metadata) {
        boolean z = true;
        Preconditions.checkArgument(bytes != null, "bytes cannot be null");
        if (metadata == null) {
            z = false;
        }
        Preconditions.checkArgument(z, "metadata cannot be null");
        UploadTask task = new UploadTask(this, metadata, bytes);
        task.queue();
        return task;
    }

    @NonNull
    public UploadTask putFile(@NonNull Uri uri) {
        Preconditions.checkArgument(uri != null, "uri cannot be null");
        UploadTask task = new UploadTask(this, null, uri, null);
        task.queue();
        return task;
    }

    @NonNull
    public UploadTask putFile(@NonNull Uri uri, @NonNull StorageMetadata metadata) {
        boolean z = true;
        Preconditions.checkArgument(uri != null, "uri cannot be null");
        if (metadata == null) {
            z = false;
        }
        Preconditions.checkArgument(z, "metadata cannot be null");
        UploadTask task = new UploadTask(this, metadata, uri, null);
        task.queue();
        return task;
    }

    @NonNull
    public UploadTask putFile(@NonNull Uri uri, @Nullable StorageMetadata metadata, @Nullable Uri existingUploadUri) {
        boolean z = true;
        Preconditions.checkArgument(uri != null, "uri cannot be null");
        if (metadata == null) {
            z = false;
        }
        Preconditions.checkArgument(z, "metadata cannot be null");
        UploadTask task = new UploadTask(this, metadata, uri, existingUploadUri);
        task.queue();
        return task;
    }

    @NonNull
    public UploadTask putStream(@NonNull InputStream stream) {
        Preconditions.checkArgument(stream != null, "stream cannot be null");
        UploadTask task = new UploadTask(this, (StorageMetadata) null, stream);
        task.queue();
        return task;
    }

    @NonNull
    public UploadTask putStream(@NonNull InputStream stream, @NonNull StorageMetadata metadata) {
        boolean z = true;
        Preconditions.checkArgument(stream != null, "stream cannot be null");
        if (metadata == null) {
            z = false;
        }
        Preconditions.checkArgument(z, "metadata cannot be null");
        UploadTask task = new UploadTask(this, metadata, stream);
        task.queue();
        return task;
    }

    @NonNull
    public List<UploadTask> getActiveUploadTasks() {
        return StorageTaskManager.getInstance().getUploadTasksUnder(this);
    }

    @NonNull
    public List<FileDownloadTask> getActiveDownloadTasks() {
        return StorageTaskManager.getInstance().getDownloadTasksUnder(this);
    }

    @NonNull
    public Task<StorageMetadata> getMetadata() {
        TaskCompletionSource<StorageMetadata> pendingResult = new TaskCompletionSource<>();
        StorageTaskScheduler.getInstance().scheduleCommand(new GetMetadataTask(this, pendingResult));
        return pendingResult.getTask();
    }

    @NonNull
    public Task<Uri> getDownloadUrl() {
        TaskCompletionSource<Uri> pendingResult = new TaskCompletionSource<>();
        StorageTaskScheduler.getInstance().scheduleCommand(new GetDownloadUrlTask(this, pendingResult));
        return pendingResult.getTask();
    }

    @NonNull
    public Task<StorageMetadata> updateMetadata(@NonNull StorageMetadata metadata) {
        Preconditions.checkNotNull(metadata);
        TaskCompletionSource<StorageMetadata> pendingResult = new TaskCompletionSource<>();
        StorageTaskScheduler.getInstance().scheduleCommand(new UpdateMetadataTask(this, pendingResult, metadata));
        return pendingResult.getTask();
    }

    @NonNull
    public Task<byte[]> getBytes(final long maxDownloadSizeBytes) {
        final TaskCompletionSource<byte[]> pendingResult = new TaskCompletionSource<>();
        StreamDownloadTask task = new StreamDownloadTask(this);
        task.setStreamProcessor(new StreamDownloadTask.StreamProcessor() { // from class: com.google.firebase.storage.StorageReference.3
            @Override // com.google.firebase.storage.StreamDownloadTask.StreamProcessor
            public void doInBackground(StreamDownloadTask.TaskSnapshot state, InputStream stream) throws IOException {
                try {
                    ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                    int totalRead = 0;
                    byte[] data = new byte[16384];
                    while (true) {
                        int nRead = stream.read(data, 0, data.length);
                        if (nRead != -1) {
                            totalRead += nRead;
                            if (totalRead > maxDownloadSizeBytes) {
                                Log.e(StorageReference.TAG, "the maximum allowed buffer size was exceeded.");
                                throw new IndexOutOfBoundsException("the maximum allowed buffer size was exceeded.");
                            }
                            buffer.write(data, 0, nRead);
                        } else {
                            buffer.flush();
                            pendingResult.setResult(buffer.toByteArray());
                            return;
                        }
                    }
                } finally {
                    stream.close();
                }
            }
        }).addOnSuccessListener((OnSuccessListener) new OnSuccessListener<StreamDownloadTask.TaskSnapshot>() { // from class: com.google.firebase.storage.StorageReference.2
            @Override // com.google.android.gms.tasks.OnSuccessListener
            public void onSuccess(StreamDownloadTask.TaskSnapshot state) {
                if (!pendingResult.getTask().isComplete()) {
                    Log.e(StorageReference.TAG, "getBytes 'succeeded', but failed to set a Result.");
                    pendingResult.setException(StorageException.fromErrorStatus(Status.RESULT_INTERNAL_ERROR));
                }
            }
        }).mo436addOnFailureListener(new OnFailureListener() { // from class: com.google.firebase.storage.StorageReference.1
            static final /* synthetic */ boolean $assertionsDisabled;

            static {
                $assertionsDisabled = !StorageReference.class.desiredAssertionStatus();
            }

            @Override // com.google.android.gms.tasks.OnFailureListener
            public void onFailure(@NonNull Exception e) {
                StorageException se = StorageException.fromExceptionAndHttpCode(e, 0);
                if ($assertionsDisabled || se != null) {
                    pendingResult.setException(se);
                    return;
                }
                throw new AssertionError();
            }
        });
        task.queue();
        return pendingResult.getTask();
    }

    @NonNull
    public FileDownloadTask getFile(@NonNull Uri destinationUri) {
        FileDownloadTask task = new FileDownloadTask(this, destinationUri);
        task.queue();
        return task;
    }

    @NonNull
    public FileDownloadTask getFile(@NonNull File destinationFile) {
        return getFile(Uri.fromFile(destinationFile));
    }

    @NonNull
    public StreamDownloadTask getStream() {
        StreamDownloadTask task = new StreamDownloadTask(this);
        task.queue();
        return task;
    }

    @NonNull
    public StreamDownloadTask getStream(@NonNull StreamDownloadTask.StreamProcessor processor) {
        StreamDownloadTask task = new StreamDownloadTask(this);
        task.setStreamProcessor(processor);
        task.queue();
        return task;
    }

    @NonNull
    public Task<Void> delete() {
        TaskCompletionSource<Void> pendingResult = new TaskCompletionSource<>();
        StorageTaskScheduler.getInstance().scheduleCommand(new DeleteStorageTask(this, pendingResult));
        return pendingResult.getTask();
    }

    @NonNull
    public Task<ListResult> list(int maxResults) {
        boolean z = true;
        Preconditions.checkArgument(maxResults > 0, "maxResults must be greater than zero");
        if (maxResults > 1000) {
            z = false;
        }
        Preconditions.checkArgument(z, "maxResults must be at most 1000");
        return listHelper(Integer.valueOf(maxResults), null);
    }

    @NonNull
    public Task<ListResult> list(int maxResults, @NonNull String pageToken) {
        boolean z = true;
        Preconditions.checkArgument(maxResults > 0, "maxResults must be greater than zero");
        Preconditions.checkArgument(maxResults <= 1000, "maxResults must be at most 1000");
        if (pageToken == null) {
            z = false;
        }
        Preconditions.checkArgument(z, "pageToken must be non-null to resume a previous list() operation");
        return listHelper(Integer.valueOf(maxResults), pageToken);
    }

    @NonNull
    public Task<ListResult> listAll() {
        final TaskCompletionSource<ListResult> pendingResult = new TaskCompletionSource<>();
        final List<StorageReference> prefixes = new ArrayList<>();
        final List<StorageReference> items = new ArrayList<>();
        final Executor executor = StorageTaskScheduler.getInstance().getCommandPoolExecutor();
        Task<ListResult> list = listHelper(null, null);
        list.continueWithTask(executor, new Continuation<ListResult, Task<Void>>() { // from class: com.google.firebase.storage.StorageReference.4
            /* JADX WARN: Can't rename method to resolve collision */
            @Override // com.google.android.gms.tasks.Continuation
            /* renamed from: then */
            public Task<Void> mo428then(@NonNull Task<ListResult> currentPage) {
                ListResult result = currentPage.mo447getResult();
                prefixes.addAll(result.getPrefixes());
                items.addAll(result.getItems());
                if (result.getPageToken() != null) {
                    Task<ListResult> nextPage = StorageReference.this.listHelper(null, result.getPageToken());
                    nextPage.continueWithTask(executor, this);
                } else {
                    pendingResult.setResult(new ListResult(prefixes, items, null));
                }
                return Tasks.forResult(null);
            }
        });
        return pendingResult.getTask();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public Task<ListResult> listHelper(@Nullable Integer maxResults, @Nullable String pageToken) {
        TaskCompletionSource<ListResult> pendingResult = new TaskCompletionSource<>();
        StorageTaskScheduler.getInstance().scheduleCommand(new ListTask(this, maxResults, pageToken, pendingResult));
        return pendingResult.getTask();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @NonNull
    public Uri getStorageUri() {
        return this.mStorageUri;
    }

    public String toString() {
        return "gs://" + this.mStorageUri.getAuthority() + this.mStorageUri.getEncodedPath();
    }

    public boolean equals(Object other) {
        if (!(other instanceof StorageReference)) {
            return false;
        }
        StorageReference otherStorage = (StorageReference) other;
        return otherStorage.toString().equals(toString());
    }

    public int hashCode() {
        return toString().hashCode();
    }

    @Override // java.lang.Comparable
    public int compareTo(@NonNull StorageReference other) {
        return this.mStorageUri.compareTo(other.mStorageUri);
    }
}
