package com.google.firebase.storage;

import android.app.Activity;
import androidx.annotation.NonNull;
import java.util.concurrent.Executor;
/* compiled from: com.google.firebase:firebase-storage@@19.0.0 */
/* loaded from: classes62.dex */
public abstract class ControllableTask<StateT> extends CancellableTask<StateT> {
    @NonNull
    /* renamed from: addOnPausedListener */
    public abstract ControllableTask<StateT> mo438addOnPausedListener(@NonNull Activity activity, @NonNull OnPausedListener<? super StateT> onPausedListener);

    @NonNull
    /* renamed from: addOnPausedListener */
    public abstract ControllableTask<StateT> mo439addOnPausedListener(@NonNull OnPausedListener<? super StateT> onPausedListener);

    @NonNull
    /* renamed from: addOnPausedListener */
    public abstract ControllableTask<StateT> mo440addOnPausedListener(@NonNull Executor executor, @NonNull OnPausedListener<? super StateT> onPausedListener);

    public abstract boolean isPaused();

    public abstract boolean pause();

    public abstract boolean resume();
}
