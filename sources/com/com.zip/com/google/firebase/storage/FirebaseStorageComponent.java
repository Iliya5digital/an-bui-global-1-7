package com.google.firebase.storage;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.internal.InternalAuthProvider;
import com.google.firebase.inject.Provider;
import java.util.HashMap;
import java.util.Map;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: com.google.firebase:firebase-storage@@19.0.0 */
/* loaded from: classes62.dex */
public class FirebaseStorageComponent {
    private final FirebaseApp app;
    @Nullable
    private final Provider<InternalAuthProvider> authProvider;
    private final Map<String, FirebaseStorage> instances = new HashMap();

    /* JADX INFO: Access modifiers changed from: package-private */
    public FirebaseStorageComponent(@NonNull FirebaseApp app, @Nullable Provider<InternalAuthProvider> authProvider) {
        this.app = app;
        this.authProvider = authProvider;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @NonNull
    public synchronized FirebaseStorage get(@Nullable String bucketName) {
        FirebaseStorage storage;
        storage = this.instances.get(bucketName);
        if (storage == null) {
            storage = new FirebaseStorage(bucketName, this.app, this.authProvider);
            this.instances.put(bucketName, storage);
        }
        return storage;
    }

    @VisibleForTesting
    synchronized void clearInstancesForTesting() {
        this.instances.clear();
    }
}
