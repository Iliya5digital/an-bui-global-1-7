package com.google.firebase.storage.network;

import android.net.Uri;
import androidx.annotation.NonNull;
import com.google.firebase.FirebaseApp;
import java.io.UnsupportedEncodingException;
import java.util.Collections;
/* compiled from: com.google.firebase:firebase-storage@@19.0.0 */
/* loaded from: classes62.dex */
public class GetNetworkRequest extends NetworkRequest {
    private static final String TAG = "GetNetworkRequest";

    public GetNetworkRequest(@NonNull Uri gsUri, @NonNull FirebaseApp app, long startByte) {
        super(gsUri, app);
        if (startByte != 0) {
            super.setCustomHeader("Range", "bytes=" + startByte + "-");
        }
    }

    @Override // com.google.firebase.storage.network.NetworkRequest
    @NonNull
    protected String getAction() {
        return "GET";
    }

    @Override // com.google.firebase.storage.network.NetworkRequest
    @NonNull
    protected String getQueryParameters() throws UnsupportedEncodingException {
        return getPostDataString(Collections.singletonList("alt"), Collections.singletonList("media"), true);
    }
}
