package com.google.firebase.storage.network;

import android.net.Uri;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.firebase.FirebaseApp;
/* compiled from: com.google.firebase:firebase-storage@@19.0.0 */
/* loaded from: classes62.dex */
public class ResumableUploadByteRequest extends ResumableNetworkRequest {
    private final int bytesToWrite;
    private final byte[] chunk;
    private final boolean isFinal;
    private final long offset;
    private final String uploadURL;

    public ResumableUploadByteRequest(@NonNull Uri gsUri, @NonNull FirebaseApp app, @NonNull String uploadURL, @Nullable byte[] chunk, long offset, int bytesToWrite, boolean isFinal) {
        super(gsUri, app);
        if (TextUtils.isEmpty(uploadURL)) {
            this.mException = new IllegalArgumentException("uploadURL is null or empty");
        }
        if (chunk == null && bytesToWrite != -1) {
            this.mException = new IllegalArgumentException("contentType is null or empty");
        }
        if (offset < 0) {
            this.mException = new IllegalArgumentException("offset cannot be negative");
        }
        this.bytesToWrite = bytesToWrite;
        this.uploadURL = uploadURL;
        this.chunk = bytesToWrite <= 0 ? null : chunk;
        this.offset = offset;
        this.isFinal = isFinal;
        super.setCustomHeader("X-Goog-Upload-Protocol", "resumable");
        if (this.isFinal && this.bytesToWrite > 0) {
            super.setCustomHeader("X-Goog-Upload-Command", "upload, finalize");
        } else if (this.isFinal) {
            super.setCustomHeader("X-Goog-Upload-Command", "finalize");
        } else {
            super.setCustomHeader("X-Goog-Upload-Command", "upload");
        }
        super.setCustomHeader("X-Goog-Upload-Offset", Long.toString(this.offset));
    }

    @Override // com.google.firebase.storage.network.NetworkRequest
    @NonNull
    protected String getAction() {
        return "POST";
    }

    @Override // com.google.firebase.storage.network.NetworkRequest
    @NonNull
    protected String getURL() {
        return this.uploadURL;
    }

    @Override // com.google.firebase.storage.network.NetworkRequest
    @Nullable
    protected byte[] getOutputRaw() {
        return this.chunk;
    }

    @Override // com.google.firebase.storage.network.NetworkRequest
    protected int getOutputRawSize() {
        if (this.bytesToWrite > 0) {
            return this.bytesToWrite;
        }
        return 0;
    }
}
