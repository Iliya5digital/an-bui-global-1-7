package com.google.firebase.storage.network;

import android.net.Uri;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import com.google.android.gms.actions.SearchIntents;
import com.google.firebase.FirebaseApp;
/* compiled from: com.google.firebase:firebase-storage@@19.0.0 */
/* loaded from: classes62.dex */
public class ResumableUploadQueryRequest extends ResumableNetworkRequest {
    private final String uploadURL;

    public ResumableUploadQueryRequest(@NonNull Uri gsUri, @NonNull FirebaseApp app, @NonNull String uploadURL) {
        super(gsUri, app);
        if (TextUtils.isEmpty(uploadURL)) {
            this.mException = new IllegalArgumentException("uploadURL is null or empty");
        }
        this.uploadURL = uploadURL;
        super.setCustomHeader("X-Goog-Upload-Protocol", "resumable");
        super.setCustomHeader("X-Goog-Upload-Command", SearchIntents.EXTRA_QUERY);
    }

    @Override // com.google.firebase.storage.network.NetworkRequest
    @NonNull
    protected String getAction() {
        return "POST";
    }

    @Override // com.google.firebase.storage.network.NetworkRequest
    @NonNull
    protected String getURL() {
        return this.uploadURL;
    }
}
