package com.google.firebase.storage.network;

import android.net.Uri;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.firebase.FirebaseApp;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
/* compiled from: com.google.firebase:firebase-storage@@19.0.0 */
/* loaded from: classes62.dex */
public class ListNetworkRequest extends NetworkRequest {
    @Nullable
    private final Integer maxPageSize;
    @Nullable
    private final String nextPageToken;

    public ListNetworkRequest(@NonNull Uri gsUri, @NonNull FirebaseApp app, @Nullable Integer maxPageSize, @Nullable String nextPageToken) {
        super(gsUri, app);
        this.maxPageSize = maxPageSize;
        this.nextPageToken = nextPageToken;
    }

    @Override // com.google.firebase.storage.network.NetworkRequest
    @NonNull
    protected String getAction() {
        return "GET";
    }

    @Override // com.google.firebase.storage.network.NetworkRequest
    @NonNull
    protected String getURL() {
        return sNetworkRequestUrl + "/b/" + this.mGsUri.getAuthority() + "/o";
    }

    @Override // com.google.firebase.storage.network.NetworkRequest
    @Nullable
    protected String getQueryParameters() throws UnsupportedEncodingException {
        List<String> keys = new ArrayList<>();
        List<String> values = new ArrayList<>();
        String prefix = getPathWithoutBucket();
        if (!TextUtils.isEmpty(prefix)) {
            keys.add("prefix");
            values.add(prefix + "/");
        }
        keys.add("delimiter");
        values.add("/");
        if (this.maxPageSize != null) {
            keys.add("maxResults");
            values.add(Integer.toString(this.maxPageSize.intValue()));
        }
        if (!TextUtils.isEmpty(this.nextPageToken)) {
            keys.add("pageToken");
            values.add(this.nextPageToken);
        }
        return getPostDataString(keys, values, true);
    }
}
