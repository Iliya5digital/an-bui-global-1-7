package com.google.firebase.storage.network;

import android.net.Uri;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.firebase.FirebaseApp;
import com.google.firebase.storage.internal.Slashes;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject;
/* compiled from: com.google.firebase:firebase-storage@@19.0.0 */
/* loaded from: classes62.dex */
public class ResumableUploadStartRequest extends ResumableNetworkRequest {
    private final String contentType;
    private final JSONObject metadata;

    public ResumableUploadStartRequest(@NonNull Uri gsUri, @NonNull FirebaseApp app, @Nullable JSONObject metadata, @NonNull String contentType) {
        super(gsUri, app);
        this.metadata = metadata;
        this.contentType = contentType;
        if (TextUtils.isEmpty(this.contentType)) {
            this.mException = new IllegalArgumentException("mContentType is null or empty");
        }
        super.setCustomHeader("X-Goog-Upload-Protocol", "resumable");
        super.setCustomHeader("X-Goog-Upload-Command", "start");
        super.setCustomHeader("X-Goog-Upload-Header-Content-Type", this.contentType);
    }

    @Override // com.google.firebase.storage.network.NetworkRequest
    @NonNull
    protected String getURL() {
        return sUploadUrl + this.mGsUri.getAuthority() + "/o";
    }

    @Override // com.google.firebase.storage.network.NetworkRequest
    @NonNull
    protected String getAction() {
        return "POST";
    }

    @Override // com.google.firebase.storage.network.NetworkRequest
    @NonNull
    protected String getQueryParameters() throws UnsupportedEncodingException {
        List<String> keys = new ArrayList<>();
        List<String> values = new ArrayList<>();
        String pathWithoutBucket = getPathWithoutBucket();
        keys.add("name");
        values.add(pathWithoutBucket != null ? Slashes.unSlashize(pathWithoutBucket) : "");
        keys.add("uploadType");
        values.add("resumable");
        return getPostDataString(keys, values, false);
    }

    @Override // com.google.firebase.storage.network.NetworkRequest
    @Nullable
    protected JSONObject getOutputJSON() {
        return this.metadata;
    }
}
