package com.google.firebase.storage.network;

import android.net.Uri;
import androidx.annotation.NonNull;
import com.google.firebase.FirebaseApp;
/* compiled from: com.google.firebase:firebase-storage@@19.0.0 */
/* loaded from: classes62.dex */
public class GetMetadataNetworkRequest extends NetworkRequest {
    public GetMetadataNetworkRequest(@NonNull Uri gsUri, @NonNull FirebaseApp app) {
        super(gsUri, app);
    }

    @Override // com.google.firebase.storage.network.NetworkRequest
    @NonNull
    protected String getAction() {
        return "GET";
    }
}
