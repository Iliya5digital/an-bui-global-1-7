package com.google.firebase.storage.network;

import android.net.Uri;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.VisibleForTesting;
import com.google.firebase.FirebaseApp;
/* compiled from: com.google.firebase:firebase-storage@@19.0.0 */
/* loaded from: classes62.dex */
public class ResumableUploadCancelRequest extends ResumableNetworkRequest {
    @VisibleForTesting
    public static boolean cancelCalled = false;
    private final String uploadURL;

    public ResumableUploadCancelRequest(@NonNull Uri gsUri, @NonNull FirebaseApp app, @NonNull String uploadURL) {
        super(gsUri, app);
        cancelCalled = true;
        if (TextUtils.isEmpty(uploadURL)) {
            this.mException = new IllegalArgumentException("uploadURL is null or empty");
        }
        this.uploadURL = uploadURL;
        super.setCustomHeader("X-Goog-Upload-Protocol", "resumable");
        super.setCustomHeader("X-Goog-Upload-Command", "cancel");
    }

    @Override // com.google.firebase.storage.network.NetworkRequest
    @NonNull
    protected String getAction() {
        return "POST";
    }

    @Override // com.google.firebase.storage.network.NetworkRequest
    @NonNull
    protected String getURL() {
        return this.uploadURL;
    }
}
