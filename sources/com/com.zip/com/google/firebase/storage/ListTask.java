package com.google.firebase.storage;

import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.firebase.storage.internal.ExponentialBackoffSender;
import com.google.firebase.storage.network.ListNetworkRequest;
import com.google.firebase.storage.network.NetworkRequest;
import org.json.JSONException;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: com.google.firebase:firebase-storage@@19.0.0 */
/* loaded from: classes62.dex */
public class ListTask implements Runnable {
    private static final String TAG = "ListTask";
    @Nullable
    private final Integer maxResults;
    @Nullable
    private final String pageToken;
    private final TaskCompletionSource<ListResult> pendingResult;
    private final ExponentialBackoffSender sender;
    private final StorageReference storageRef;

    /* JADX INFO: Access modifiers changed from: package-private */
    public ListTask(@NonNull StorageReference storageRef, @Nullable Integer maxResults, @Nullable String pageToken, @NonNull TaskCompletionSource<ListResult> pendingResult) {
        Preconditions.checkNotNull(storageRef);
        Preconditions.checkNotNull(pendingResult);
        this.storageRef = storageRef;
        this.maxResults = maxResults;
        this.pageToken = pageToken;
        this.pendingResult = pendingResult;
        FirebaseStorage storage = this.storageRef.getStorage();
        this.sender = new ExponentialBackoffSender(storage.getApp().getApplicationContext(), storage.getAuthProvider(), storage.getMaxDownloadRetryTimeMillis());
    }

    @Override // java.lang.Runnable
    public void run() {
        NetworkRequest request = new ListNetworkRequest(this.storageRef.getStorageUri(), this.storageRef.getApp(), this.maxResults, this.pageToken);
        this.sender.sendWithExponentialBackoff(request);
        ListResult listResult = null;
        if (request.isResultSuccess()) {
            try {
                listResult = ListResult.fromJSON(this.storageRef.getStorage(), request.getResultBody());
            } catch (JSONException e) {
                Log.e(TAG, "Unable to parse response body. " + request.getRawResult(), e);
                this.pendingResult.setException(StorageException.fromException(e));
                return;
            }
        }
        if (this.pendingResult != null) {
            request.completeTask(this.pendingResult, listResult);
        }
    }
}
