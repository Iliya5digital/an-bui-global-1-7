package com.google.firebase.iid;

import androidx.annotation.NonNull;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.Task;
/* loaded from: classes72.dex */
final class zzu implements Continuation<T, Void> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public zzu(zzs zzsVar) {
    }

    @Override // com.google.android.gms.tasks.Continuation
    /* renamed from: then */
    public final /* bridge */ /* synthetic */ Void mo428then(@NonNull Task task) throws Exception {
        return null;
    }
}
