package com.google.firebase.iid;
/* loaded from: classes72.dex */
final class zzaa extends Exception {
    /* JADX INFO: Access modifiers changed from: package-private */
    public zzaa(String str) {
        super(str);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzaa(Exception exc) {
        super(exc);
    }
}
