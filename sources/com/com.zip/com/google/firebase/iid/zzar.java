package com.google.firebase.iid;

import com.google.android.gms.tasks.Task;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes72.dex */
public interface zzar {
    Task<InstanceIdResult> zzs();
}
