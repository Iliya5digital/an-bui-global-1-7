package com.google.firebase.components;

import com.google.firebase.inject.Provider;
import java.util.Collections;
/* compiled from: com.google.firebase:firebase-common@@19.0.0 */
/* loaded from: classes53.dex */
final /* synthetic */ class ComponentRuntime$$Lambda$3 implements Provider {
    private static final ComponentRuntime$$Lambda$3 instance = new ComponentRuntime$$Lambda$3();

    private ComponentRuntime$$Lambda$3() {
    }

    @Override // com.google.firebase.inject.Provider
    public Object get() {
        return Collections.emptySet();
    }
}
