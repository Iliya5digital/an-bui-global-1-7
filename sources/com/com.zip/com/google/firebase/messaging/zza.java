package com.google.firebase.messaging;

import androidx.core.app.NotificationCompat;
/* loaded from: classes71.dex */
public final class zza {
    public final int id = 0;
    public final String tag;
    public final NotificationCompat.Builder zzds;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zza(NotificationCompat.Builder builder, String str, int i) {
        this.zzds = builder;
        this.tag = str;
    }
}
