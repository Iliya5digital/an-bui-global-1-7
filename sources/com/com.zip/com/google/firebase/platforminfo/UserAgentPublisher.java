package com.google.firebase.platforminfo;
/* compiled from: com.google.firebase:firebase-common@@19.0.0 */
/* loaded from: classes53.dex */
public interface UserAgentPublisher {
    String getUserAgent();
}
