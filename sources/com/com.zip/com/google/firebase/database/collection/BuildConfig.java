package com.google.firebase.database.collection;
/* compiled from: com.google.firebase:firebase-database-collection@@16.0.1 */
/* loaded from: classes61.dex */
public final class BuildConfig {
    public static final String APPLICATION_ID = "com.google.firebase.database.collection";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final int VERSION_CODE = -1;
    public static final String VERSION_NAME = "";
}
