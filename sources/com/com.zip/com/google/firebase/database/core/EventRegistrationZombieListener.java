package com.google.firebase.database.core;
/* compiled from: com.google.firebase:firebase-database@@19.0.0 */
/* loaded from: classes60.dex */
public interface EventRegistrationZombieListener {
    void onZombied(EventRegistration eventRegistration);
}
