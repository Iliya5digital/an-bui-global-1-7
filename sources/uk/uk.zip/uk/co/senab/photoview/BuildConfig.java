package uk.co.senab.photoview;
/* loaded from: classes78.dex */
public final class BuildConfig {
    public static final String APPLICATION_ID = "uk.co.senab.photoview";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final int VERSION_CODE = 124;
    public static final String VERSION_NAME = "1.2.4";
}
