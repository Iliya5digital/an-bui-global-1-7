package org.apache.http.cookie;
@Deprecated
/* loaded from: classes.dex */
public interface SM {
    public static final String COOKIE = "Cookie";
    public static final String COOKIE2 = "Cookie2";
    public static final String SET_COOKIE = "Set-Cookie";
    public static final String SET_COOKIE2 = "Set-Cookie2";
}
