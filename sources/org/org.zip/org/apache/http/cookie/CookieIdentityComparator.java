package org.apache.http.cookie;

import java.io.Serializable;
import java.util.Comparator;
@Deprecated
/* loaded from: classes.dex */
public class CookieIdentityComparator implements Serializable, Comparator<Cookie> {
    public CookieIdentityComparator() {
        throw new RuntimeException("Stub!");
    }

    @Override // java.util.Comparator
    public int compare(Cookie c1, Cookie c2) {
        throw new RuntimeException("Stub!");
    }
}
