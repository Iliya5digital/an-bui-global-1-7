package org.apache.http.cookie;

import org.apache.http.params.HttpParams;
@Deprecated
/* loaded from: classes.dex */
public interface CookieSpecFactory {
    CookieSpec newInstance(HttpParams httpParams);
}
