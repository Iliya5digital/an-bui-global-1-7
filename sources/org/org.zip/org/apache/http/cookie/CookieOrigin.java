package org.apache.http.cookie;
@Deprecated
/* loaded from: classes.dex */
public final class CookieOrigin {
    public CookieOrigin(String host, int port, String path, boolean secure) {
        throw new RuntimeException("Stub!");
    }

    public String getHost() {
        throw new RuntimeException("Stub!");
    }

    public String getPath() {
        throw new RuntimeException("Stub!");
    }

    public int getPort() {
        throw new RuntimeException("Stub!");
    }

    public boolean isSecure() {
        throw new RuntimeException("Stub!");
    }

    public String toString() {
        throw new RuntimeException("Stub!");
    }
}
