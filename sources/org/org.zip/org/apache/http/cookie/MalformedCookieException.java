package org.apache.http.cookie;

import org.apache.http.ProtocolException;
@Deprecated
/* loaded from: classes.dex */
public class MalformedCookieException extends ProtocolException {
    public MalformedCookieException() {
        throw new RuntimeException("Stub!");
    }

    public MalformedCookieException(String message) {
        throw new RuntimeException("Stub!");
    }

    public MalformedCookieException(String message, Throwable cause) {
        throw new RuntimeException("Stub!");
    }
}
