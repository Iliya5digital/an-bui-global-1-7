package org.apache.http.cookie;
@Deprecated
/* loaded from: classes.dex */
public interface SetCookie2 extends SetCookie {
    void setCommentURL(String str);

    void setDiscard(boolean z);

    void setPorts(int[] iArr);
}
