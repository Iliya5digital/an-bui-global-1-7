package org.apache.http.message;
@Deprecated
/* loaded from: classes.dex */
public class ParserCursor {
    public ParserCursor(int lowerBound, int upperBound) {
        throw new RuntimeException("Stub!");
    }

    public int getLowerBound() {
        throw new RuntimeException("Stub!");
    }

    public int getUpperBound() {
        throw new RuntimeException("Stub!");
    }

    public int getPos() {
        throw new RuntimeException("Stub!");
    }

    public void updatePos(int pos) {
        throw new RuntimeException("Stub!");
    }

    public boolean atEnd() {
        throw new RuntimeException("Stub!");
    }

    public String toString() {
        throw new RuntimeException("Stub!");
    }
}
