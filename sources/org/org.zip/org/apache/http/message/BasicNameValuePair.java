package org.apache.http.message;

import org.apache.http.NameValuePair;
@Deprecated
/* loaded from: classes.dex */
public class BasicNameValuePair implements NameValuePair {
    public BasicNameValuePair(String name, String value) {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.NameValuePair
    public String getName() {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.NameValuePair
    public String getValue() {
        throw new RuntimeException("Stub!");
    }

    public String toString() {
        throw new RuntimeException("Stub!");
    }

    public boolean equals(Object object) {
        throw new RuntimeException("Stub!");
    }

    public int hashCode() {
        throw new RuntimeException("Stub!");
    }

    public Object clone() throws CloneNotSupportedException {
        throw new RuntimeException("Stub!");
    }
}
