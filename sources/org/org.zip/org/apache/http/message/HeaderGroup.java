package org.apache.http.message;

import org.apache.http.Header;
import org.apache.http.HeaderIterator;
@Deprecated
/* loaded from: classes.dex */
public class HeaderGroup {
    public HeaderGroup() {
        throw new RuntimeException("Stub!");
    }

    public void clear() {
        throw new RuntimeException("Stub!");
    }

    public void addHeader(Header header) {
        throw new RuntimeException("Stub!");
    }

    public void removeHeader(Header header) {
        throw new RuntimeException("Stub!");
    }

    public void updateHeader(Header header) {
        throw new RuntimeException("Stub!");
    }

    public void setHeaders(Header[] headers) {
        throw new RuntimeException("Stub!");
    }

    public Header getCondensedHeader(String name) {
        throw new RuntimeException("Stub!");
    }

    public Header[] getHeaders(String name) {
        throw new RuntimeException("Stub!");
    }

    public Header getFirstHeader(String name) {
        throw new RuntimeException("Stub!");
    }

    public Header getLastHeader(String name) {
        throw new RuntimeException("Stub!");
    }

    public Header[] getAllHeaders() {
        throw new RuntimeException("Stub!");
    }

    public boolean containsHeader(String name) {
        throw new RuntimeException("Stub!");
    }

    public HeaderIterator iterator() {
        throw new RuntimeException("Stub!");
    }

    public HeaderIterator iterator(String name) {
        throw new RuntimeException("Stub!");
    }

    public HeaderGroup copy() {
        throw new RuntimeException("Stub!");
    }

    public Object clone() throws CloneNotSupportedException {
        throw new RuntimeException("Stub!");
    }
}
