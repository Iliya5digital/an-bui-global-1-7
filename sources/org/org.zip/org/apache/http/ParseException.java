package org.apache.http;
@Deprecated
/* loaded from: classes.dex */
public class ParseException extends RuntimeException {
    public ParseException() {
        throw new RuntimeException("Stub!");
    }

    public ParseException(String message) {
        throw new RuntimeException("Stub!");
    }
}
