package org.apache.http;

import java.io.IOException;
@Deprecated
/* loaded from: classes.dex */
public class MalformedChunkCodingException extends IOException {
    public MalformedChunkCodingException() {
        throw new RuntimeException("Stub!");
    }

    public MalformedChunkCodingException(String message) {
        throw new RuntimeException("Stub!");
    }
}
