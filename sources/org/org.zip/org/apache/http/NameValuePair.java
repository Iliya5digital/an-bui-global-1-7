package org.apache.http;
@Deprecated
/* loaded from: classes.dex */
public interface NameValuePair {
    String getName();

    String getValue();
}
