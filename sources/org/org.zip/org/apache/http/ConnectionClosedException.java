package org.apache.http;

import java.io.IOException;
@Deprecated
/* loaded from: classes.dex */
public class ConnectionClosedException extends IOException {
    public ConnectionClosedException(String message) {
        throw new RuntimeException("Stub!");
    }
}
