package org.apache.http;
@Deprecated
/* loaded from: classes.dex */
public class ProtocolException extends HttpException {
    public ProtocolException() {
        throw new RuntimeException("Stub!");
    }

    public ProtocolException(String message) {
        throw new RuntimeException("Stub!");
    }

    public ProtocolException(String message, Throwable cause) {
        throw new RuntimeException("Stub!");
    }
}
