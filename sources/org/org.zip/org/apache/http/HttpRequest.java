package org.apache.http;
@Deprecated
/* loaded from: classes.dex */
public interface HttpRequest extends HttpMessage {
    RequestLine getRequestLine();
}
