package org.apache.http.client;

import org.apache.http.ProtocolException;
@Deprecated
/* loaded from: classes.dex */
public class NonRepeatableRequestException extends ProtocolException {
    public NonRepeatableRequestException() {
        throw new RuntimeException("Stub!");
    }

    public NonRepeatableRequestException(String message) {
        throw new RuntimeException("Stub!");
    }
}
