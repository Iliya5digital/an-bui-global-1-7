package org.apache.http.client.methods;

import java.net.URI;
@Deprecated
/* loaded from: classes.dex */
public class HttpDelete extends HttpRequestBase {
    public static final String METHOD_NAME = "DELETE";

    public HttpDelete() {
        throw new RuntimeException("Stub!");
    }

    public HttpDelete(URI uri) {
        throw new RuntimeException("Stub!");
    }

    public HttpDelete(String uri) {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.client.methods.HttpRequestBase, org.apache.http.client.methods.HttpUriRequest
    public String getMethod() {
        throw new RuntimeException("Stub!");
    }
}
