package org.apache.http.client.methods;

import java.net.URI;
@Deprecated
/* loaded from: classes.dex */
public class HttpPut extends HttpEntityEnclosingRequestBase {
    public static final String METHOD_NAME = "PUT";

    public HttpPut() {
        throw new RuntimeException("Stub!");
    }

    public HttpPut(URI uri) {
        throw new RuntimeException("Stub!");
    }

    public HttpPut(String uri) {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.client.methods.HttpRequestBase, org.apache.http.client.methods.HttpUriRequest
    public String getMethod() {
        throw new RuntimeException("Stub!");
    }
}
