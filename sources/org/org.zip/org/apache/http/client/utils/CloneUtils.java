package org.apache.http.client.utils;
@Deprecated
/* loaded from: classes.dex */
public class CloneUtils {
    CloneUtils() {
        throw new RuntimeException("Stub!");
    }

    public static Object clone(Object obj) throws CloneNotSupportedException {
        throw new RuntimeException("Stub!");
    }
}
