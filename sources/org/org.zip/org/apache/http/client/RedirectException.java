package org.apache.http.client;

import org.apache.http.ProtocolException;
@Deprecated
/* loaded from: classes.dex */
public class RedirectException extends ProtocolException {
    public RedirectException() {
        throw new RuntimeException("Stub!");
    }

    public RedirectException(String message) {
        throw new RuntimeException("Stub!");
    }

    public RedirectException(String message, Throwable cause) {
        throw new RuntimeException("Stub!");
    }
}
