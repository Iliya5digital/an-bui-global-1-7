package org.apache.http.client;
@Deprecated
/* loaded from: classes.dex */
public class CircularRedirectException extends RedirectException {
    public CircularRedirectException() {
        throw new RuntimeException("Stub!");
    }

    public CircularRedirectException(String message) {
        throw new RuntimeException("Stub!");
    }

    public CircularRedirectException(String message, Throwable cause) {
        throw new RuntimeException("Stub!");
    }
}
