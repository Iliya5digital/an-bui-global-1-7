package org.apache.http.client.params;

import org.apache.http.params.HttpParams;
@Deprecated
/* loaded from: classes.dex */
public class HttpClientParams {
    HttpClientParams() {
        throw new RuntimeException("Stub!");
    }

    public static boolean isRedirecting(HttpParams params) {
        throw new RuntimeException("Stub!");
    }

    public static void setRedirecting(HttpParams params, boolean value) {
        throw new RuntimeException("Stub!");
    }

    public static boolean isAuthenticating(HttpParams params) {
        throw new RuntimeException("Stub!");
    }

    public static void setAuthenticating(HttpParams params, boolean value) {
        throw new RuntimeException("Stub!");
    }

    public static String getCookiePolicy(HttpParams params) {
        throw new RuntimeException("Stub!");
    }

    public static void setCookiePolicy(HttpParams params, String cookiePolicy) {
        throw new RuntimeException("Stub!");
    }
}
