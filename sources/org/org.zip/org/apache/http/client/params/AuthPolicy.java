package org.apache.http.client.params;
@Deprecated
/* loaded from: classes.dex */
public final class AuthPolicy {
    public static final String BASIC = "Basic";
    public static final String DIGEST = "Digest";
    public static final String NTLM = "NTLM";

    AuthPolicy() {
        throw new RuntimeException("Stub!");
    }
}
