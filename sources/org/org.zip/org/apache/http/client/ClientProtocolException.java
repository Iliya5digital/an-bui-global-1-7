package org.apache.http.client;

import java.io.IOException;
@Deprecated
/* loaded from: classes.dex */
public class ClientProtocolException extends IOException {
    public ClientProtocolException() {
        throw new RuntimeException("Stub!");
    }

    public ClientProtocolException(String s) {
        throw new RuntimeException("Stub!");
    }

    public ClientProtocolException(Throwable cause) {
        throw new RuntimeException("Stub!");
    }

    public ClientProtocolException(String message, Throwable cause) {
        throw new RuntimeException("Stub!");
    }
}
