package org.apache.http.util;
@Deprecated
/* loaded from: classes.dex */
public final class ExceptionUtils {
    ExceptionUtils() {
        throw new RuntimeException("Stub!");
    }

    public static void initCause(Throwable throwable, Throwable cause) {
        throw new RuntimeException("Stub!");
    }
}
