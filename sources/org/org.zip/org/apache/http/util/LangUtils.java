package org.apache.http.util;
@Deprecated
/* loaded from: classes.dex */
public final class LangUtils {
    public static final int HASH_OFFSET = 37;
    public static final int HASH_SEED = 17;

    LangUtils() {
        throw new RuntimeException("Stub!");
    }

    public static int hashCode(int seed, int hashcode) {
        throw new RuntimeException("Stub!");
    }

    public static int hashCode(int seed, boolean b) {
        throw new RuntimeException("Stub!");
    }

    public static int hashCode(int seed, Object obj) {
        throw new RuntimeException("Stub!");
    }

    public static boolean equals(Object obj1, Object obj2) {
        throw new RuntimeException("Stub!");
    }

    public static boolean equals(Object[] a1, Object[] a2) {
        throw new RuntimeException("Stub!");
    }
}
