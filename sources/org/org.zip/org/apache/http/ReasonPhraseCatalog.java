package org.apache.http;

import java.util.Locale;
@Deprecated
/* loaded from: classes.dex */
public interface ReasonPhraseCatalog {
    String getReason(int i, Locale locale);
}
