package org.apache.http.protocol;
@Deprecated
/* loaded from: classes.dex */
public interface HttpRequestHandlerResolver {
    HttpRequestHandler lookup(String str);
}
