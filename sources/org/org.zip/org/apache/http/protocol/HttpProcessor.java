package org.apache.http.protocol;

import org.apache.http.HttpRequestInterceptor;
import org.apache.http.HttpResponseInterceptor;
@Deprecated
/* loaded from: classes.dex */
public interface HttpProcessor extends HttpRequestInterceptor, HttpResponseInterceptor {
}
