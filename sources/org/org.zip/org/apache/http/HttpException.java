package org.apache.http;
@Deprecated
/* loaded from: classes.dex */
public class HttpException extends Exception {
    public HttpException() {
        throw new RuntimeException("Stub!");
    }

    public HttpException(String message) {
        throw new RuntimeException("Stub!");
    }

    public HttpException(String message, Throwable cause) {
        throw new RuntimeException("Stub!");
    }
}
