package org.apache.http.conn.scheme;
@Deprecated
/* loaded from: classes.dex */
public final class Scheme {
    public Scheme(String name, SocketFactory factory, int port) {
        throw new RuntimeException("Stub!");
    }

    public int getDefaultPort() {
        throw new RuntimeException("Stub!");
    }

    public SocketFactory getSocketFactory() {
        throw new RuntimeException("Stub!");
    }

    public String getName() {
        throw new RuntimeException("Stub!");
    }

    public boolean isLayered() {
        throw new RuntimeException("Stub!");
    }

    public int resolvePort(int port) {
        throw new RuntimeException("Stub!");
    }

    public String toString() {
        throw new RuntimeException("Stub!");
    }

    public boolean equals(Object obj) {
        throw new RuntimeException("Stub!");
    }

    public int hashCode() {
        throw new RuntimeException("Stub!");
    }
}
