package org.apache.http.conn.params;
@Deprecated
/* loaded from: classes.dex */
public interface ConnConnectionPNames {
    public static final String MAX_STATUS_LINE_GARBAGE = "http.connection.max-status-line-garbage";
}
