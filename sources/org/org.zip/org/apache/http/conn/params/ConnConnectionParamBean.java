package org.apache.http.conn.params;

import org.apache.http.params.HttpAbstractParamBean;
import org.apache.http.params.HttpParams;
@Deprecated
/* loaded from: classes.dex */
public class ConnConnectionParamBean extends HttpAbstractParamBean {
    public ConnConnectionParamBean(HttpParams params) {
        super(null);
        throw new RuntimeException("Stub!");
    }

    public void setMaxStatusLineGarbage(int maxStatusLineGarbage) {
        throw new RuntimeException("Stub!");
    }
}
