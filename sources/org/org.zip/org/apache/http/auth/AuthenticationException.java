package org.apache.http.auth;

import org.apache.http.ProtocolException;
@Deprecated
/* loaded from: classes.dex */
public class AuthenticationException extends ProtocolException {
    public AuthenticationException() {
        throw new RuntimeException("Stub!");
    }

    public AuthenticationException(String message) {
        throw new RuntimeException("Stub!");
    }

    public AuthenticationException(String message, Throwable cause) {
        throw new RuntimeException("Stub!");
    }
}
