package org.apache.http.auth;

import org.apache.http.ProtocolException;
@Deprecated
/* loaded from: classes.dex */
public class MalformedChallengeException extends ProtocolException {
    public MalformedChallengeException() {
        throw new RuntimeException("Stub!");
    }

    public MalformedChallengeException(String message) {
        throw new RuntimeException("Stub!");
    }

    public MalformedChallengeException(String message, Throwable cause) {
        throw new RuntimeException("Stub!");
    }
}
