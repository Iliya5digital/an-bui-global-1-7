package org.apache.http.auth.params;
@Deprecated
/* loaded from: classes.dex */
public interface AuthPNames {
    public static final String CREDENTIAL_CHARSET = "http.auth.credential-charset";
}
