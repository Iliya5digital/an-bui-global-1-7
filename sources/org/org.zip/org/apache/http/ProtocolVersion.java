package org.apache.http;

import java.io.Serializable;
@Deprecated
/* loaded from: classes.dex */
public class ProtocolVersion implements Serializable {
    protected final int major;
    protected final int minor;
    protected final String protocol;

    public ProtocolVersion(String protocol, int major, int minor) {
        throw new RuntimeException("Stub!");
    }

    public final String getProtocol() {
        throw new RuntimeException("Stub!");
    }

    public final int getMajor() {
        throw new RuntimeException("Stub!");
    }

    public final int getMinor() {
        throw new RuntimeException("Stub!");
    }

    public ProtocolVersion forVersion(int major, int minor) {
        throw new RuntimeException("Stub!");
    }

    public final int hashCode() {
        throw new RuntimeException("Stub!");
    }

    public final boolean equals(Object obj) {
        throw new RuntimeException("Stub!");
    }

    public boolean isComparable(ProtocolVersion that) {
        throw new RuntimeException("Stub!");
    }

    public int compareToVersion(ProtocolVersion that) {
        throw new RuntimeException("Stub!");
    }

    public final boolean greaterEquals(ProtocolVersion version) {
        throw new RuntimeException("Stub!");
    }

    public final boolean lessEquals(ProtocolVersion version) {
        throw new RuntimeException("Stub!");
    }

    public String toString() {
        throw new RuntimeException("Stub!");
    }

    public Object clone() throws CloneNotSupportedException {
        throw new RuntimeException("Stub!");
    }
}
