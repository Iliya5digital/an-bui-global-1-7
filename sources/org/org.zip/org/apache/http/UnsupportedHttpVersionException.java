package org.apache.http;
@Deprecated
/* loaded from: classes.dex */
public class UnsupportedHttpVersionException extends ProtocolException {
    public UnsupportedHttpVersionException() {
        throw new RuntimeException("Stub!");
    }

    public UnsupportedHttpVersionException(String message) {
        throw new RuntimeException("Stub!");
    }
}
