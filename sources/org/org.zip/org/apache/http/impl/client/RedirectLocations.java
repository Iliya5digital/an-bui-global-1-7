package org.apache.http.impl.client;

import java.net.URI;
@Deprecated
/* loaded from: classes.dex */
public class RedirectLocations {
    public RedirectLocations() {
        throw new RuntimeException("Stub!");
    }

    public boolean contains(URI uri) {
        throw new RuntimeException("Stub!");
    }

    public void add(URI uri) {
        throw new RuntimeException("Stub!");
    }

    public boolean remove(URI uri) {
        throw new RuntimeException("Stub!");
    }
}
