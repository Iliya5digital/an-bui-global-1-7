package org.apache.http.impl.auth;
@Deprecated
/* loaded from: classes.dex */
public class UnsupportedDigestAlgorithmException extends RuntimeException {
    public UnsupportedDigestAlgorithmException() {
        throw new RuntimeException("Stub!");
    }

    public UnsupportedDigestAlgorithmException(String message) {
        throw new RuntimeException("Stub!");
    }

    public UnsupportedDigestAlgorithmException(String message, Throwable cause) {
        throw new RuntimeException("Stub!");
    }
}
