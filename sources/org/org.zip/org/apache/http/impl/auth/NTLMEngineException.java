package org.apache.http.impl.auth;

import org.apache.http.auth.AuthenticationException;
@Deprecated
/* loaded from: classes.dex */
public class NTLMEngineException extends AuthenticationException {
    public NTLMEngineException() {
        throw new RuntimeException("Stub!");
    }

    public NTLMEngineException(String message) {
        throw new RuntimeException("Stub!");
    }

    public NTLMEngineException(String message, Throwable cause) {
        throw new RuntimeException("Stub!");
    }
}
