package org.apache.http.impl.conn;

import java.io.IOException;
import java.io.InputStream;
import org.apache.commons.logging.Log;
@Deprecated
/* loaded from: classes.dex */
public class Wire {
    public Wire(Log log) {
        throw new RuntimeException("Stub!");
    }

    public boolean enabled() {
        throw new RuntimeException("Stub!");
    }

    public void output(InputStream outstream) throws IOException {
        throw new RuntimeException("Stub!");
    }

    public void input(InputStream instream) throws IOException {
        throw new RuntimeException("Stub!");
    }

    public void output(byte[] b, int off, int len) throws IOException {
        throw new RuntimeException("Stub!");
    }

    public void input(byte[] b, int off, int len) throws IOException {
        throw new RuntimeException("Stub!");
    }

    public void output(byte[] b) throws IOException {
        throw new RuntimeException("Stub!");
    }

    public void input(byte[] b) throws IOException {
        throw new RuntimeException("Stub!");
    }

    public void output(int b) throws IOException {
        throw new RuntimeException("Stub!");
    }

    public void input(int b) throws IOException {
        throw new RuntimeException("Stub!");
    }

    public void output(String s) throws IOException {
        throw new RuntimeException("Stub!");
    }

    public void input(String s) throws IOException {
        throw new RuntimeException("Stub!");
    }
}
