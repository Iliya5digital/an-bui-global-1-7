package org.apache.http.impl.conn.tsccm;
@Deprecated
/* loaded from: classes.dex */
public class WaitingThreadAborter {
    public WaitingThreadAborter() {
        throw new RuntimeException("Stub!");
    }

    public void abort() {
        throw new RuntimeException("Stub!");
    }

    public void setWaitingThread(WaitingThread waitingThread) {
        throw new RuntimeException("Stub!");
    }
}
