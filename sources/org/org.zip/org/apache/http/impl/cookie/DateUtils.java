package org.apache.http.impl.cookie;

import java.util.Date;
import java.util.TimeZone;
@Deprecated
/* loaded from: classes.dex */
public final class DateUtils {
    public static final TimeZone GMT = null;
    public static final String PATTERN_ASCTIME = "EEE MMM d HH:mm:ss yyyy";
    public static final String PATTERN_RFC1036 = "EEEE, dd-MMM-yy HH:mm:ss zzz";
    public static final String PATTERN_RFC1123 = "EEE, dd MMM yyyy HH:mm:ss zzz";

    DateUtils() {
        throw new RuntimeException("Stub!");
    }

    public static Date parseDate(String dateValue) throws DateParseException {
        throw new RuntimeException("Stub!");
    }

    public static Date parseDate(String dateValue, String[] dateFormats) throws DateParseException {
        throw new RuntimeException("Stub!");
    }

    public static Date parseDate(String dateValue, String[] dateFormats, Date startDate) throws DateParseException {
        throw new RuntimeException("Stub!");
    }

    public static String formatDate(Date date) {
        throw new RuntimeException("Stub!");
    }

    public static String formatDate(Date date, String pattern) {
        throw new RuntimeException("Stub!");
    }
}
