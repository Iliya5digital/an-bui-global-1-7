package org.apache.http.impl.cookie;

import org.apache.http.cookie.CookieSpec;
import org.apache.http.cookie.CookieSpecFactory;
import org.apache.http.params.HttpParams;
@Deprecated
/* loaded from: classes.dex */
public class BrowserCompatSpecFactory implements CookieSpecFactory {
    public BrowserCompatSpecFactory() {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.cookie.CookieSpecFactory
    public CookieSpec newInstance(HttpParams params) {
        throw new RuntimeException("Stub!");
    }
}
