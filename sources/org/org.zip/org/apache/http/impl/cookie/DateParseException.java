package org.apache.http.impl.cookie;
@Deprecated
/* loaded from: classes.dex */
public class DateParseException extends Exception {
    public DateParseException() {
        throw new RuntimeException("Stub!");
    }

    public DateParseException(String message) {
        throw new RuntimeException("Stub!");
    }
}
