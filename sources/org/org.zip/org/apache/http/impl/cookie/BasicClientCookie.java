package org.apache.http.impl.cookie;

import java.util.Date;
import org.apache.http.cookie.ClientCookie;
import org.apache.http.cookie.SetCookie;
@Deprecated
/* loaded from: classes.dex */
public class BasicClientCookie implements SetCookie, ClientCookie {
    public BasicClientCookie(String name, String value) {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.cookie.Cookie
    public String getName() {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.cookie.Cookie
    public String getValue() {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.cookie.SetCookie
    public void setValue(String value) {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.cookie.Cookie
    public String getComment() {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.cookie.SetCookie
    public void setComment(String comment) {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.cookie.Cookie
    public String getCommentURL() {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.cookie.Cookie
    public Date getExpiryDate() {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.cookie.SetCookie
    public void setExpiryDate(Date expiryDate) {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.cookie.Cookie
    public boolean isPersistent() {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.cookie.Cookie
    public String getDomain() {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.cookie.SetCookie
    public void setDomain(String domain) {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.cookie.Cookie
    public String getPath() {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.cookie.SetCookie
    public void setPath(String path) {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.cookie.Cookie
    public boolean isSecure() {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.cookie.SetCookie
    public void setSecure(boolean secure) {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.cookie.Cookie
    public int[] getPorts() {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.cookie.Cookie
    public int getVersion() {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.cookie.SetCookie
    public void setVersion(int version) {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.cookie.Cookie
    public boolean isExpired(Date date) {
        throw new RuntimeException("Stub!");
    }

    public void setAttribute(String name, String value) {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.cookie.ClientCookie
    public String getAttribute(String name) {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.http.cookie.ClientCookie
    public boolean containsAttribute(String name) {
        throw new RuntimeException("Stub!");
    }

    public Object clone() throws CloneNotSupportedException {
        throw new RuntimeException("Stub!");
    }

    public String toString() {
        throw new RuntimeException("Stub!");
    }
}
