package org.apache.http.impl.cookie;

import org.apache.http.HeaderElement;
import org.apache.http.ParseException;
import org.apache.http.message.ParserCursor;
import org.apache.http.util.CharArrayBuffer;
@Deprecated
/* loaded from: classes.dex */
public class NetscapeDraftHeaderParser {
    public static final NetscapeDraftHeaderParser DEFAULT = null;

    public NetscapeDraftHeaderParser() {
        throw new RuntimeException("Stub!");
    }

    public HeaderElement parseHeader(CharArrayBuffer buffer, ParserCursor cursor) throws ParseException {
        throw new RuntimeException("Stub!");
    }
}
