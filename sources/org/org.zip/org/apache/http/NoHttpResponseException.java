package org.apache.http;

import java.io.IOException;
@Deprecated
/* loaded from: classes.dex */
public class NoHttpResponseException extends IOException {
    public NoHttpResponseException(String message) {
        throw new RuntimeException("Stub!");
    }
}
