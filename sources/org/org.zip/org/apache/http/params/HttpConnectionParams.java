package org.apache.http.params;
@Deprecated
/* loaded from: classes.dex */
public final class HttpConnectionParams implements CoreConnectionPNames {
    HttpConnectionParams() {
        throw new RuntimeException("Stub!");
    }

    public static int getSoTimeout(HttpParams params) {
        throw new RuntimeException("Stub!");
    }

    public static void setSoTimeout(HttpParams params, int timeout) {
        throw new RuntimeException("Stub!");
    }

    public static boolean getTcpNoDelay(HttpParams params) {
        throw new RuntimeException("Stub!");
    }

    public static void setTcpNoDelay(HttpParams params, boolean value) {
        throw new RuntimeException("Stub!");
    }

    public static int getSocketBufferSize(HttpParams params) {
        throw new RuntimeException("Stub!");
    }

    public static void setSocketBufferSize(HttpParams params, int size) {
        throw new RuntimeException("Stub!");
    }

    public static int getLinger(HttpParams params) {
        throw new RuntimeException("Stub!");
    }

    public static void setLinger(HttpParams params, int value) {
        throw new RuntimeException("Stub!");
    }

    public static int getConnectionTimeout(HttpParams params) {
        throw new RuntimeException("Stub!");
    }

    public static void setConnectionTimeout(HttpParams params, int timeout) {
        throw new RuntimeException("Stub!");
    }

    public static boolean isStaleCheckingEnabled(HttpParams params) {
        throw new RuntimeException("Stub!");
    }

    public static void setStaleCheckingEnabled(HttpParams params, boolean value) {
        throw new RuntimeException("Stub!");
    }
}
