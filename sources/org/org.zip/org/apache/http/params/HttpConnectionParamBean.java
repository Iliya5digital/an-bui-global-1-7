package org.apache.http.params;
@Deprecated
/* loaded from: classes.dex */
public class HttpConnectionParamBean extends HttpAbstractParamBean {
    public HttpConnectionParamBean(HttpParams params) {
        super(null);
        throw new RuntimeException("Stub!");
    }

    public void setSoTimeout(int soTimeout) {
        throw new RuntimeException("Stub!");
    }

    public void setTcpNoDelay(boolean tcpNoDelay) {
        throw new RuntimeException("Stub!");
    }

    public void setSocketBufferSize(int socketBufferSize) {
        throw new RuntimeException("Stub!");
    }

    public void setLinger(int linger) {
        throw new RuntimeException("Stub!");
    }

    public void setConnectionTimeout(int connectionTimeout) {
        throw new RuntimeException("Stub!");
    }

    public void setStaleCheckingEnabled(boolean staleCheckingEnabled) {
        throw new RuntimeException("Stub!");
    }
}
