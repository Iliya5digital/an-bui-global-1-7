package org.apache.http.params;

import org.apache.http.ProtocolVersion;
@Deprecated
/* loaded from: classes.dex */
public final class HttpProtocolParams implements CoreProtocolPNames {
    HttpProtocolParams() {
        throw new RuntimeException("Stub!");
    }

    public static String getHttpElementCharset(HttpParams params) {
        throw new RuntimeException("Stub!");
    }

    public static void setHttpElementCharset(HttpParams params, String charset) {
        throw new RuntimeException("Stub!");
    }

    public static String getContentCharset(HttpParams params) {
        throw new RuntimeException("Stub!");
    }

    public static void setContentCharset(HttpParams params, String charset) {
        throw new RuntimeException("Stub!");
    }

    public static ProtocolVersion getVersion(HttpParams params) {
        throw new RuntimeException("Stub!");
    }

    public static void setVersion(HttpParams params, ProtocolVersion version) {
        throw new RuntimeException("Stub!");
    }

    public static String getUserAgent(HttpParams params) {
        throw new RuntimeException("Stub!");
    }

    public static void setUserAgent(HttpParams params, String useragent) {
        throw new RuntimeException("Stub!");
    }

    public static boolean useExpectContinue(HttpParams params) {
        throw new RuntimeException("Stub!");
    }

    public static void setUseExpectContinue(HttpParams params, boolean b) {
        throw new RuntimeException("Stub!");
    }
}
