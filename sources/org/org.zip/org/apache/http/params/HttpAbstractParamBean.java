package org.apache.http.params;
@Deprecated
/* loaded from: classes.dex */
public abstract class HttpAbstractParamBean {
    protected final HttpParams params;

    public HttpAbstractParamBean(HttpParams params) {
        throw new RuntimeException("Stub!");
    }
}
