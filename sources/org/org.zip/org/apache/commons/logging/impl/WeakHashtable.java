package org.apache.commons.logging.impl;

import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;
@Deprecated
/* loaded from: classes.dex */
public final class WeakHashtable extends Hashtable {
    public WeakHashtable() {
        throw new RuntimeException("Stub!");
    }

    @Override // java.util.Hashtable, java.util.Map
    public boolean containsKey(Object key) {
        throw new RuntimeException("Stub!");
    }

    @Override // java.util.Hashtable, java.util.Dictionary
    public Enumeration elements() {
        throw new RuntimeException("Stub!");
    }

    @Override // java.util.Hashtable, java.util.Map
    public Set entrySet() {
        throw new RuntimeException("Stub!");
    }

    @Override // java.util.Hashtable, java.util.Dictionary, java.util.Map
    public Object get(Object key) {
        throw new RuntimeException("Stub!");
    }

    @Override // java.util.Hashtable, java.util.Dictionary
    public Enumeration keys() {
        throw new RuntimeException("Stub!");
    }

    @Override // java.util.Hashtable, java.util.Map
    public Set keySet() {
        throw new RuntimeException("Stub!");
    }

    @Override // java.util.Hashtable, java.util.Dictionary, java.util.Map
    public Object put(Object key, Object value) {
        throw new RuntimeException("Stub!");
    }

    @Override // java.util.Hashtable, java.util.Map
    public void putAll(Map t) {
        throw new RuntimeException("Stub!");
    }

    @Override // java.util.Hashtable, java.util.Map
    public Collection values() {
        throw new RuntimeException("Stub!");
    }

    @Override // java.util.Hashtable, java.util.Dictionary, java.util.Map
    public Object remove(Object key) {
        throw new RuntimeException("Stub!");
    }

    @Override // java.util.Hashtable, java.util.Dictionary, java.util.Map
    public boolean isEmpty() {
        throw new RuntimeException("Stub!");
    }

    @Override // java.util.Hashtable, java.util.Dictionary, java.util.Map
    public int size() {
        throw new RuntimeException("Stub!");
    }

    @Override // java.util.Hashtable
    public String toString() {
        throw new RuntimeException("Stub!");
    }

    @Override // java.util.Hashtable
    protected void rehash() {
        throw new RuntimeException("Stub!");
    }
}
