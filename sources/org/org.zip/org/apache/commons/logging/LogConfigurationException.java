package org.apache.commons.logging;
@Deprecated
/* loaded from: classes.dex */
public class LogConfigurationException extends RuntimeException {
    protected Throwable cause;

    public LogConfigurationException() {
        throw new RuntimeException("Stub!");
    }

    public LogConfigurationException(String message) {
        throw new RuntimeException("Stub!");
    }

    public LogConfigurationException(Throwable cause) {
        throw new RuntimeException("Stub!");
    }

    public LogConfigurationException(String message, Throwable cause) {
        throw new RuntimeException("Stub!");
    }

    @Override // java.lang.Throwable
    public Throwable getCause() {
        throw new RuntimeException("Stub!");
    }
}
