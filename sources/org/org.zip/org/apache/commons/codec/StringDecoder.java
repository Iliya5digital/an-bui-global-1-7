package org.apache.commons.codec;
@Deprecated
/* loaded from: classes.dex */
public interface StringDecoder extends Decoder {
    String decode(String str) throws DecoderException;
}
