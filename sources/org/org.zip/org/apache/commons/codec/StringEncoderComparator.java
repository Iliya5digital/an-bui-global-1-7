package org.apache.commons.codec;

import java.util.Comparator;
@Deprecated
/* loaded from: classes.dex */
public class StringEncoderComparator implements Comparator {
    public StringEncoderComparator() {
        throw new RuntimeException("Stub!");
    }

    public StringEncoderComparator(StringEncoder stringEncoder) {
        throw new RuntimeException("Stub!");
    }

    @Override // java.util.Comparator
    public int compare(Object o1, Object o2) {
        throw new RuntimeException("Stub!");
    }
}
