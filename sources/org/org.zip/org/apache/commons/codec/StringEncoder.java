package org.apache.commons.codec;
@Deprecated
/* loaded from: classes.dex */
public interface StringEncoder extends Encoder {
    String encode(String str) throws EncoderException;
}
