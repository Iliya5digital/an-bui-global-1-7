package org.apache.commons.codec;
@Deprecated
/* loaded from: classes.dex */
public class EncoderException extends Exception {
    public EncoderException(String pMessage) {
        throw new RuntimeException("Stub!");
    }
}
