package org.apache.commons.codec;
@Deprecated
/* loaded from: classes.dex */
public class DecoderException extends Exception {
    public DecoderException(String pMessage) {
        throw new RuntimeException("Stub!");
    }
}
