package org.apache.commons.codec;
@Deprecated
/* loaded from: classes.dex */
public interface Encoder {
    Object encode(Object obj) throws EncoderException;
}
