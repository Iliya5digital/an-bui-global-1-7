package org.apache.commons.codec.language;

import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.StringEncoder;
@Deprecated
/* loaded from: classes.dex */
public class Metaphone implements StringEncoder {
    public Metaphone() {
        throw new RuntimeException("Stub!");
    }

    public String metaphone(String txt) {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.commons.codec.Encoder
    public Object encode(Object pObject) throws EncoderException {
        throw new RuntimeException("Stub!");
    }

    @Override // org.apache.commons.codec.StringEncoder
    public String encode(String pString) {
        throw new RuntimeException("Stub!");
    }

    public boolean isMetaphoneEqual(String str1, String str2) {
        throw new RuntimeException("Stub!");
    }

    public int getMaxCodeLen() {
        throw new RuntimeException("Stub!");
    }

    public void setMaxCodeLen(int maxCodeLen) {
        throw new RuntimeException("Stub!");
    }
}
