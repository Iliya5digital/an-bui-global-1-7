package org.apache.commons.codec;
@Deprecated
/* loaded from: classes.dex */
public interface BinaryDecoder extends Decoder {
    byte[] decode(byte[] bArr) throws DecoderException;
}
